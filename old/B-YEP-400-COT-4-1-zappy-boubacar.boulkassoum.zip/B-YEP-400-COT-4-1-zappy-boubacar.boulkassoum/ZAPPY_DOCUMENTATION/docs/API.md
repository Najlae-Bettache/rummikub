# <span style="font-family: 'Times New Roman', Times, serif; color: red">API Documentation

### <span style="font-family: 'Times New Roman', Times, serif;">Server-Client Commands

##### <span style="font-family: 'Times New Roman', Times, serif;">msz X Y
Returns the map size.

##### <span style="font-family: 'Times New Roman', Times, serif;">bct X Y q0 q1 q2 q3 q4 q5 q6
Returns the content of a tile.

##### <span style="font-family: 'Times New Roman', Times, serif;">tna N
Returns the names of all teams.

##### <span style="font-family: 'Times New Roman', Times, serif;">pnw #n X Y O L N
New player connection.

##### <span style="font-family: 'Times New Roman', Times, serif;">ppo #n X Y O
Player's position.

##### <span style="font-family: 'Times New Roman', Times, serif;">plv #n L
Player's level.

##### <span style="font-family: 'Times New Roman', Times, serif;">pin #n X Y q0 q1 q2 q3 q4 q5 q6
Player's inventory.

##### <span style="font-family: 'Times New Roman', Times, serif;">pex #n
Expulsion.

##### <span style="font-family: 'Times New Roman', Times, serif;">pbc #n M
Broadcast.

##### <span style="font-family: 'Times New Roman', Times, serif;">pic X Y L #n #n ...
Start of an incantation.

##### <span style="font-family: 'Times New Roman', Times, serif;">pie X Y R
End of an incantation.

##### <span style="font-family: 'Times New Roman', Times, serif;">pfk #n
Player laying an egg.

##### <span style="font-family: 'Times New Roman', Times, serif;">pdr #n i
Resource dropping.

##### <span style="font-family: 'Times New Roman', Times, serif;">pgt #n i
Resource collecting.

##### <span style="font-family: 'Times New Roman', Times, serif;">pdi #n
Player death.

##### <span style="font-family: 'Times New Roman', Times, serif;">enw #e #n X Y
An egg was laid by a player.

##### <span style="font-family: 'Times New Roman', Times, serif;">ebo #e
Player connection to an egg.

##### <span style="font-family: 'Times New Roman', Times, serif;">edi #e
Egg death.

##### <span style="font-family: 'Times New Roman', Times, serif;">sgt T
Time unit request.

##### <span style="font-family: 'Times New Roman', Times, serif;">sst T
Time unit modification.

##### <span style="font-family: 'Times New Roman', Times, serif;">seg N
End of game.

##### <span style="font-family: 'Times New Roman', Times, serif;">smg M
Message from the server.

##### <span style="font-family: 'Times New Roman', Times, serif;">suc
Unknown command.

##### <span style="font-family: 'Times New Roman', Times, serif;">sbp
Command parameter.