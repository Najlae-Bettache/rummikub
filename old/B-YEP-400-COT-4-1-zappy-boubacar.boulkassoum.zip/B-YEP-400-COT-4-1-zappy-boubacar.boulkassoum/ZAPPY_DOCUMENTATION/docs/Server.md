# <span style="font-family: 'Times New Roman', Times, serif; color:red">Server

## <span style="font-family: 'Times New Roman', Times, serif;">Introduction
The server is the core component of the Zappy project, responsible for managing the game world and coordinating the actions of the clients.

## <span style="font-family: 'Times New Roman', Times, serif;">Code
#### (ici ajouter le nom d'un fichier et faire les signes comme ceux qu'il y'a dans mon fichier ai.md)