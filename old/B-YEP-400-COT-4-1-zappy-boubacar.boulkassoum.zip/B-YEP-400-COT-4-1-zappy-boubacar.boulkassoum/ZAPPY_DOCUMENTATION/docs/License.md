# <span style="font-family: 'Times New Roman', Times, serif; color:red">License

This project is licensed under the MIT License. See the LICENSE file for details.
