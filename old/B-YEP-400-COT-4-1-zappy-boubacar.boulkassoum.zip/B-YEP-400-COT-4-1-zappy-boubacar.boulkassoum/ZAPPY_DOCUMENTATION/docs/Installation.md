# <span style="font-family: 'Times New Roman', Times, serif; color:red">Installation

To compile the project, use the provided Makefile:

```sh
make
```

Go to the [Usage](Usage.md) section to find out what to do next
