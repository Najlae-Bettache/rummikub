# ![Zappy](https://pbs.twimg.com/profile_images/1668253777894227969/oBfeqN1J_400x400.jpg)


## <span style="font-family: 'Times New Roman', Times, serif;">Introduction
Zappy is a network game project where multiple teams compete on a resource-filled map. The objective is to have the team reach the maximum elevation first.

## <span style="font-family: 'Times New Roman', Times, serif;">Prerequisites
- C and C++ compilers (gcc, g++)
- [SFML](https://www.sfml-dev.org/) for the graphical interface

## <span style="font-family: 'Times New Roman', Times, serif;">Installation
See [Installation](Installation.md)

## <span style="font-family: 'Times New Roman', Times, serif;">Usage
See [Usage](Usage.md)

## <span style="font-family: 'Times New Roman', Times, serif;">API Documentation
See [API Documentation](API.md)

## <span style="font-family: 'Times New Roman', Times, serif;">Contributions
See [Contributing](Contributing.md)

## <span style="font-family: 'Times New Roman', Times, serif;">License
See [License](License.md)

## <span style="font-family: 'Times New Roman', Times, serif;">Code Explore
See [Server](Server.md) for the code related to the Server management  
See [Gui](Gui.md) for the code related to the Gui management  
See [Ai](Ai.md) for the code related to the Ai management  
