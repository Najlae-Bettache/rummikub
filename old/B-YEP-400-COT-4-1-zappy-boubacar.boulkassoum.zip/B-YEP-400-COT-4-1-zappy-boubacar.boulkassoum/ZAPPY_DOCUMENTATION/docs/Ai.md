# <span style="font-family: 'Times New Roman', Times, serif; color: red;">AI

## <span style="font-family: 'Times New Roman', Times, serif;">Introduction
The AI client autonomously controls a player, sending commands to the server to perform actions in the game world.

## <span style="font-family: 'Times New Roman', Times, serif;">Code
#### <span style="font-family: 'Times New Roman', Times, serif;">*ai.py*
```python
import socket
import time

class ZappyAI:
    def __init__(self, host, port, team_name):
        self.host = host
        self.port = port
        self.team_name = team_name
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.inventory = {}
        self.client_num = None
        self.world_size = (None, None)
        self.current_level = 1

    def connect(self):
        try:
            self.sock.connect((self.host, self.port))
            welcome_message = self.sock.recv(1024).decode().strip()
            print(f"Received: {welcome_message}")

            if welcome_message == "Welcome Player":
                self.sock.sendall(f"{self.team_name}\n".encode())
                time.sleep(0.5)
                self.handle_server_messages()
            else:
                print("Failed to receive Welcome Player message from server.")
        except Exception as e:
            print(f"An error occurred: {e}")
            self.close()

    def handle_server_messages(self):
        try:
            response = self.sock.recv(1024).decode().strip()

            if response:
                parts = response.split('\n')
                if len(parts) >= 2:
                    client_num_response = parts[0]
                    world_size_response = parts[1]

                    self.client_num = int(client_num_response)
                    print(f"Client number: {self.client_num}")

                    world_size_parts = world_size_response.split()
                    if len(world_size_parts) == 2:
                        self.world_size = (int(world_size_parts[0]), int(world_size_parts[1]))
                        print(f"World size: {self.world_size}")

                    if len(parts) > 2 and parts[2] == "dead":
                        print("Received 'dead' message, disconnecting.")
                        self.close()
                        return
                    
                    self.main_loop()
                else:
                    print("Failed to parse the server response correctly.")
            else:
                print("No response received, retrying...")
                time.sleep(0.5)
        except Exception as e:
            print(f"An error occurred while handling server messages: {e}")
            self.close()

    def send_command(self, command):
        try:
            print(f"Sending command: {command}")
            self.sock.sendall(f"{command}\n".encode())
            time.sleep(0.1)
            response = self.sock.recv(1024).decode()
            print(f"Received response: {response}")
            return response
        except Exception as e:
            print(f"An error occurred while sending command '{command}': {e}")
            self.close()

    def move_forward(self):
        return self.send_command('Forward')

    def turn_right(self):
        return self.send_command('Right')

    def turn_left(self):
        return self.send_command('Left')

    def look_around(self):
        return self.send_command('Look')

    def check_inventory(self):
        return self.send_command('Inventory')

    def broadcast_message(self, message):
        return self.send_command(f'Broadcast {message}')

    def connect_nbr(self):
        return self.send_command('Connect_nbr')

    def fork_player(self):
        return self.send_command('Fork')

    def eject_players(self):
        return self.send_command('Eject')

    def take_object(self, obj):
        return self.send_command(f'Take {obj}')

    def set_object_down(self, obj):
        return self.send_command(f'Set {obj}')

    def start_incantation(self):
        return self.send_command('Incantation')

    def collect_resource(self, resource, vision):
        for i, cell in enumerate(vision):
            if resource in cell:
                self.move_to_cell(i)
                self.take_object(resource)
                return
        self.move_forward()

    def parse_inventory_response(self, response):
        print(f"Parsing inventory response: {response}")
        response = response.strip().lstrip('{').rstrip('}')
        inventory = {}
        for item in response.split(', '):
            try:
                item = item.strip('[] ')
                key, value = item.split()
                value = ''.join(filter(str.isdigit, value))
                inventory[key] = int(value)
            except ValueError as e:
                print(f"Error parsing item '{item}': {e}")
        return inventory

    def parse_look_response(self, response):
        response = response.strip().lstrip('{').rstrip('}')
        return [cell.split() for cell in response.split(', ')]

    def decide_next_action(self, vision, inventory):
        required_resources = {
            1: {},
            2: {'linemate': 1},
            3: {'linemate': 1, 'deraumere': 1, 'sibur': 1},
            4: {'linemate': 2, 'sibur': 1, 'phiras': 2},
            5: {'linemate': 1, 'deraumere': 1, 'sibur': 2, 'phiras': 1},
            6: {'linemate': 1, 'deraumere': 2, 'sibur': 1, 'mendiane': 3},
            7: {'linemate': 1, 'deraumere': 2, 'sibur': 3, 'phiras': 1},
            8: {'linemate': 2, 'deraumere': 2, 'sibur': 2, 'mendiane': 2, 'phiras': 2, 'thystame': 1},
        }

        needed_resources = required_resources.get(self.current_level, {})
        for resource, amount in needed_resources.items():
            if inventory.get(resource, 0) < amount:
                self.collect_resource(resource, vision)
                return

        if inventory.get('food', 0) < 5:
            self.collect_resource('food', vision)
        else:
            self.check_incantation()

    def check_incantation(self):
        required_resources = {
            1: {},
            2: {'linemate': 1},
            3: {'linemate': 1, 'deraumere': 1, 'sibur': 1},
            4: {'linemate': 2, 'sibur': 1, 'phiras': 2},
            5: {'linemate': 1, 'deraumere': 1, 'sibur': 2, 'phiras': 1},
            6: {'linemate': 1, 'deraumere': 2, 'sibur': 1, 'mendiane': 3},
            7: {'linemate': 1, 'deraumere': 2, 'sibur': 3, 'phiras': 1},
            8: {'linemate': 2, 'deraumere': 2, 'sibur': 2, 'mendiane': 2, 'phiras': 2, 'thystame': 1},
        }

        needed_resources = required_resources.get(self.current_level, {})
        if all(self.inventory.get(resource, 0) >= amount for resource, amount in required_resources[self.current_level].items()):
            self.broadcast_message('Incantation')
            response = self.start_incantation()
            print(response)
            self.current_level += 1

    def move_to_cell(self, cell_index):
        print(f"Moving to cell: {cell_index}")
        if cell_index == 0:
            return

        moves = []
        if cell_index == 1:
            moves = ['Forward']
        elif cell_index in [2, 3]:
            moves = ['Forward'] * 2
        elif cell_index in [4, 5, 6, 7, 8]:
            moves = ['Forward'] * 3
            if cell_index == 4:
                moves.append('Left')
            elif cell_index == 5:
                moves.append('Forward')
            elif cell_index == 6:
                moves.append('Right')
            elif cell_index == 7:
                moves.extend(['Right', 'Forward'])
            elif cell_index == 8:
                moves.extend(['Right', 'Right'])

        for move in moves:
            self.send_command(move)
            time.sleep(0.1)

    def main_loop(self):
        while True:
            look_response = self.look_around()
            print(f"Look response: {look_response}")
            vision = self.parse_look_response(look_response)
            inventory_response = self.check_inventory()
            print(f"Inventory response: {inventory_response}")
            self.inventory = self.parse_inventory_response(inventory_response)
            self.decide_next_action(vision, self.inventory)
            time.sleep(0.1)
    
    def close(self):
        try:
            self.sock.close()
        except Exception as e:
            print(f"An error occurred while closing the socket: {e}")
```

#### <span style="font-family: 'Times New Roman', Times, serif;">*main.py*
```python
#!/usr/bin/env python3

import argparse
from zappy_ai.ai import ZappyAI

def main():
    parser = argparse.ArgumentParser(description="Zappy AI Client")
    parser.add_argument('--host', type=str, default='localhost', help='Server hostname')
    parser.add_argument('--port', type=int, required=True, help='Server port')
    parser.add_argument('--team_name', type=str, required=True, help='Team name')

    args = parser.parse_args()

    ai = ZappyAI(args.host, args.port, args.team_name)
    try:
        ai.connect()
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        ai.close()

if __name__ == "__main__":
    main()
```

#### <span style="font-family: 'Times New Roman', Times, serif;">*Makefile*
```python
SOURCE = main.py

BINARY = zappy_ai

all: $(BINARY)

$(BINARY): $(SOURCE)
	cp $(SOURCE) $(BINARY)
	chmod 777 $(BINARY)

clean:
	rm -f $(BINARY)

fclean: all clean
```