# <span style="font-family: 'Times New Roman', Times, serif; color:red">Usage

## <span style="font-family: 'Times New Roman', Times, serif;">Server
To launch the server:

*./zappy_server -p <port> -x <width> -y <height> -n <team_names> -c <clients_nb> -f <freq>*

##### <span style="font-family: 'Times New Roman', Times, serif;">Flags Description:

    **-p <port>** : The port number on which the server will listen.
    **-x <width>** : The width of the world map.
    **-y <height>** : The height of the world map.
    **-n <team_names>** : The names of the teams. Multiple team names can be specified.
    **-c <clients_nb>** : The number of allowed clients per team.
    **-f <freq>** : The reciprocal of time unit for action execution.

## <span style="font-family: 'Times New Roman', Times, serif;">Graphical Client
To launch the graphical client:

*./zappy_gui -p <port> -h <hostname>*

##### <span style="font-family: 'Times New Roman', Times, serif;">Flags Description:

    **-p <port>** : The port number of the server.
    **-h <hostname>** : The hostname of the server.

## <span style="font-family: 'Times New Roman', Times, serif;">AI Client
To launch the AI client:

*./zappy_ai -p <port> -n <team_name> -h <hostname>*

##### <span style="font-family: 'Times New Roman', Times, serif;">Flags Description:

    **-p <port>** : The port number of the server.
    **-n <team_name>** : The name of the team.
    **-h <hostname>** : The hostname of the server (default is localhost).

