# <span style="font-family: 'Times New Roman', Times, serif; color:red">GUI

## <span style="font-family: 'Times New Roman', Times, serif;">Introduction
The graphical client allows users to visually observe the game world and the actions of the players.

## <span style="font-family: 'Times New Roman', Times, serif;">Code
#### <span style="font-family: 'Times New Roman', Times, serif; color:orange">*tiles.hpp*
This file contains the classes of tiles, it sprites and texture.
It also contains the necessary functions to draw the tiles

The board class contains the utility functions to draw board around the screen, the boxes

```
/*
** EPITECH PROJECT, 2024
** zappy
** File description:
** header.hpp
*/
#include "header.hpp"

#ifndef TILE_HPP
  #define TILE_HPP

  class Tile {
public:
    Tile(sf::Texture& texture, float x, float y);

    void setResources(const Resources& res,
    const std::unordered_map<std::string, sf::Texture>& textures);
    bool isMouseOver(const sf::Vector2f& mousePos) const;
    void draw(sf::RenderWindow& window);
    const Resources& getResources() const;
    bool isClicked(const sf::Vector2f& mousePos, sf::Event event) const;
    
private:
    sf::Sprite sprite;
    sf::Vector2f position;
    Resources resources;
    std::vector<sf::Sprite> resourceSprites;
};

class Board {
public:
    Board();
    void setResources(const Resources& resources);
    void draw(sf::RenderWindow& window);

private:
    sf::Font font;
    sf::Text text;
    Resources resources;
};

#endif // TILE_HPP

```


#### <span style="font-family: 'Times New Roman', Times, serif; color:orange">*Makefile*
The makefile of the graphics part of the programme
```
##
## EPITECH PROJECT, 2022
## Makefile
## File description:
## Makefile
##

SRC	=	exemple.cpp	\
		input.cpp	\
		gui_main.cpp	\
		tiles.cpp	\
		send_commands.cpp	\
		parse_commands.cpp	\
		draw_map.cpp

CPPFLAGS = -std=c++20 -Wall -Wextra -Werror

OBJ	=	$(SRC:.cpp=.o)

NAME	=	zappy_gui

all:	$(NAME)

$(NAME):	$(OBJ)
	g++ $(CPPFLAGS) -o $(NAME) $(OBJ) -lsfml-graphics -lsfml-window -lsfml-system -lsfml-network
clean:
	rm -f $(OBJ)

fclean:	clean
	rm -f $(NAME)
	rm -f *~
	rm -f *#
	rm -f unit_tests
	rm -f *.gcda
	rm -f *.gcno
	find . -name "*.o" -type f -delete

re:	fclean	all

```


#### <span style="font-family: 'Times New Roman', Times, serif; color:orange">*input.cpp*
This function has been added at the beginning to manage the player sprite by managing it, handling user input, in future deeper using. For example if something happens whe will set a boolean value to true and do some actions
with the following function
```
/*
** EPITECH PROJECT, 2023
** C++game1_Udemy
** File description:
** input.cpp
*/

#include "input.hpp"

Input::Input()
{
    button.left = button.right = button.up = button.down = button.escape = button.attack = false;
}

Input::~Input() {}

Input::Button Input::getButton(void) const
{
    return button;
}
    
void Input::inputHandler(Event event, RenderWindow &window) 
{
    if (event.type == Event::Closed) {
        window.close();
    }

    if (event.type == Event::KeyPressed) {
        
        switch (event.key.code) {

        case Keyboard::Escape :
            button.escape = true;
            break;
        
        case Keyboard::Left :
            button.left = true;
            break;
        
        case Keyboard::Right :
            button.right = true;
            break;
        
        case Keyboard::Up :
            button.up = true;
            break;
        
        case Keyboard::Down :
            button.down = true;
            break;
        
        default:
            break;
        }
    }


    if (event.type == Event::KeyReleased) {
        switch (event.key.code)
        {
        case Keyboard::Escape :
            button.escape = false;
            break;
        
        case Keyboard::Left :
            button.left = false;
            break;
        
        case Keyboard::Right :
            button.right = false;
            break;
        
        case Keyboard::Up :
            button.up = false;
            break;
        
        case Keyboard::Down :
            button.down = false;
            break;
        
        default:
            break;
        }
    }

    if (event.type == Event::MouseButtonPressed) {

        if (event.mouseButton.button == Mouse::Left) {
            button.attack = true;
        }

    } 

    if (event.type == Event::MouseButtonReleased) {

        if (event.mouseButton.button == Mouse::Left) {
            button.attack = false;
        }

    } 
}
```

#### <span style="font-family: 'Times New Roman', Times, serif; color:orange">*input.hpp*
The header of input.cpp, which has been used at the beginning of the graphics part to display the player sprite and manage it movements

```
/*
** EPITECH PROJECT, 2023
** C++game1_Udemy
** File description:
** input.hpp
*/
// #include "header.hpp"

// #ifndef INPUT_HPP
//     #define INPUT_HPP
// class Input
// {
//     struct Button
//     {
//         bool left, right, up, down, attack, escape;  
//     };

//     public:
//         Input();
//         ~Input();
//         void inputHandler(Event event, RenderWindow &window);
//         Button getButton(void) const;
        
//     private:
//         Button button;
// };
// enum Dir {Down, Right, Up, Left, Down_attack, Right_attack, Up_attack, Left_attack};
// struct Contenter {
//         Font font;
//         Text txt;
//         RenderWindow window;
//         Input input;
//         int posX = 1;
//         char temp[256];
//         Texture heroTexture;
//         Sprite heroSprite;
//         Clock heroAnimClock;
//         bool heroIdle = true;
//         bool needResetAnim = false;
// };

// #endif
```
## <span style="font-family: 'Times New Roman', Times, serif;color:purple;">Classes
#### <span style="font-family: 'Times New Roman', Times, serif; color:orange;">*broadcast.hpp*
This file contains the broadcast class for broadcasting animation events
The class contains the broadcast functions, variables and so on.

```
// BroadcastAnimation.hpp
#ifndef BROADCASTANIMATION_HPP
#define BROADCASTANIMATION_HPP

#include <SFML/Graphics.hpp>
#include <string>
#include <vector>

class BroadcastAnimation {
public:
    BroadcastAnimation();
    void startAnimation(const std::string& message, const sf::Vector2f& startPosition);
    void update();
    void draw(sf::RenderWindow *window);

private:
    struct AnimatedCharacter {
        sf::Text text;
        sf::Vector2f velocity;
        sf::Clock clock;
    };

    std::vector<AnimatedCharacter> characters;
    sf::Font font;
    sf::Vector2f startPosition;
    size_t currentCharIndex;
    sf::Clock animationClock;
};

#endif

```

#### <span style="font-family: 'Times New Roman', Times, serif; color:orange;">*broadcast.cpp*
This file contains the broadcast functions to do the animation when broadcasting is enabled

```
// BroadcastAnimation.cpp
#include "broadcast.hpp"

BroadcastAnimation::BroadcastAnimation() : currentCharIndex(0) {
    if (!font.loadFromFile("font/arial.ttf")) {
        throw std::runtime_error("Failed to load font");
    }
}

void BroadcastAnimation::startAnimation(const std::string& message, const sf::Vector2f& startPosition) {
    this->startPosition = startPosition;
    currentCharIndex = 0;
    characters.clear();
    animationClock.restart();

    for (char c : message) {
        AnimatedCharacter animChar;
        animChar.text.setFont(font);
        animChar.text.setString(c);
        animChar.text.setPosition(startPosition);
        animChar.velocity = sf::Vector2f(0, -50);
        characters.push_back(animChar);
    }
}

void BroadcastAnimation::update() {
    float deltaTime = animationClock.restart().asSeconds();

    for (auto& animChar : characters) {
        if (animChar.clock.getElapsedTime().asSeconds() > 0.1f * currentCharIndex) {
            animChar.text.move(animChar.velocity * deltaTime);
            animChar.text.setFillColor(sf::Color(255, 255, 255, 255 - static_cast<int>(animChar.clock.getElapsedTime().asSeconds() * 255 / 2))); // Fade out over 2 seconds
        }
    }

    if (currentCharIndex < characters.size() && characters[currentCharIndex].clock.getElapsedTime().asSeconds() > 0.1f) {
        characters[currentCharIndex].clock.restart();
        currentCharIndex++;
    }
}

void BroadcastAnimation::draw(sf::RenderWindow *window) {
    for (const auto& animChar : characters) {
        if (animChar.clock.getElapsedTime().asSeconds() < 2) {
            window->draw(animChar.text);
        }
    }
}
```

#### <span style="font-family: 'Times New Roman', Times, serif; color:orange;">*gui.hpp (the graphical module part)*
This file contains the class of all GUI components
Display map, draw eggs, handle view, draw player, render broadcast, the Map data, title separation size, tiles size

```
#ifndef GUI_HPP
#define GUI_HPP

#include <SFML/Graphics.hpp>
#include "header.hpp"
#include "tiles.hpp"

class GUI {
public:
    GUI();
    void loadTextures();
    void handle_view(sf::View* view, float deltaTime, float moveSpeed, float zoomFactor);
    void draw_map(sf::RenderWindow* window, mapdata_t* map, 
                 const std::unordered_map<std::string, sf::Texture>& textures,
                 const std::vector<PlayerData>& players, 
                 const std::vector<Egg>& eggs, 
                 const Broadcast& broadcast);
    void draw_egg(sf::RenderWindow* window, mapdata_t* mapData, const std::vector<Egg>& eggs);
    void draw_player(sf::RenderWindow* window, const std::vector<PlayerData>& players, mapdata_t* mapData);
    void render_broadcast(sf::RenderWindow* window, const Broadcast& broadcast, const sf::Font& font);

private:
    mapdata_t* mapData;
    BroadcastAnimation broadcastAnimation;
    const int tileSize = 20;
    const int spacing = 500;

};

#endif 
```

#### <span style="font-family: 'Times New Roman', Times, serif; color:orange;">*gui.main.cpp (the graphical module part)*

This file contains the implementation of the `gui.hpp`
functions
```
#include "header.hpp"
#include "tiles.hpp"
#include "send_commands.hpp"
#include "parse_commands.hpp"
#include "gui.hpp"

CommandParser parser;
GUI gui;
std::unordered_map<std::string, sf::Texture> loadResourceTextures() {
    std::unordered_map<std::string, sf::Texture> textures;

    const std::vector<std::pair<std::string, std::string>> resourceFiles = {
        {"food", "images/food1.png"},
        {"linemate", "images/linemate.png"},
        {"deraumere", "images/deraumere.png"},
        {"sibur", "images/sibur.png"},
        {"mendiane", "images/mendiane.png"},
        {"phiras", "images/phiras.png"},
        {"thystame", "images/thystame.png"},
        {"player", "images/hero_sheet1.png"},
        {"egg", "images/egg.png"}
    };

    for (const auto& resource : resourceFiles) {
        sf::Texture texture;
        if (texture.loadFromFile(resource.second)) {
            textures[resource.first] = texture;
        } else {
            std::cerr << "Failed to load texture for " << resource.first << std::endl;
        }
    }

    return textures;
}

void handle_server_messages(const std::vector<std::string>& messages, mapdata_t* mapData,
    const std::unordered_map<std::string, sf::Texture>& textures,
    TeamData* teamData, std::vector<PlayerData>& players, std::vector<Egg>& eggs, Broadcast& broadcast) {
    for (const std::string& message : messages) {
        if (message.substr(0, 3) == "bct") {
            parser.parse_bct_message(message, mapData);
        } else if (message.substr(0, 3) == "tna") {
            parser.parse_tna_message(message, teamData);
        } else if (message.substr(0, 3) == "ppo") {
            parser.parse_ppo_message(message, players);
        } else if (message.substr(0, 3) == "plv") {
            parser.parse_plv_message(message, players);
        } else if (message.substr(0, 3) == "pnw") {
            parser.parse_pnw_message(message, players, textures, mapData);
        } else if (message.substr(0, 3) == "pin") {
            parser.parse_pin_message(message, players);
        } else if (message.substr(0, 3) == "pdi") {
            parser.parse_pdi_command(message, players, mapData);
        } else if (message.substr(0, 3) == "enw") {
            parser.parse_enw_command(message, eggs, textures);
        } else if (message.substr(0, 3) == "pbc") {
            parser.parse_pbc_command(message, players, broadcast);
        } else if (message.substr(0, 3) == "pic") {
            parser.parse_pic_command(message, players);
        } else if (message.substr(0, 3) == "edi") {
            parser.parse_edi_command(message, eggs);
        }
    }
}

void get_map_size(sf::TcpSocket* socket, mapdata_t* map) {
    std::string message = "msz\n";
    if (socket->send(message.c_str(), message.size()) != sf::Socket::Done) {
        std::cerr << "Failed to send msz message" << std::endl;
        return;
    }
    std::cout << "Sent: " << message << std::endl;

    char buffer[1000024];
    std::size_t received;
    sf::Socket::Status receiveStatus = socket->receive(buffer, sizeof(buffer) - 1, received);
    if (receiveStatus == sf::Socket::Done) {
        buffer[received] = '\0';
        std::cout << "Received from server in msz function: " << buffer << std::endl;

        std::istringstream iss(buffer);
        std::string command;
        iss >> command;
        if (command == "msz") {
            int x, y;
            iss >> x >> y;
            map->width = x;
            map->height = y;
            map->tiles.resize(map->height, std::vector<TileData>(map->width));
            std::cout << "Map size set to " << x << " x " << y << std::endl;
        }
    } else {
        std::cerr << "Failed to receive data from server" << std::endl;
    }
}

int gui_server(const std::string& machine, unsigned short port, mapdata_t* map) {
    sf::TcpSocket socket;
    sf::Socket::Status status = socket.connect(machine, port);
    TeamData teamData;
    Broadcast broadcast;
    PlayerMessageSender msg;
    std::vector<PlayerData> players;
    std::vector<Egg> eggs;
    if (status != sf::Socket::Done) {
        std::cerr << "Connection failed" << std::endl;
        return -1;
    }

    if (socket.send("GUI\n", 4) != sf::Socket::Done) {
        std::cerr << "Failed to send GUI message" << std::endl;
        return -1;
    }
    std::cout << "GUI message sent successfully" << std::endl;

    sf::sleep(sf::milliseconds(500));

    char initialBuffer[1024];
    std::size_t initialReceived;
    status = socket.receive(initialBuffer, sizeof(initialBuffer) - 1, initialReceived);
    if (status == sf::Socket::Done) {
        initialBuffer[initialReceived] = '\0';
        std::cout << "Initial server response: " << initialBuffer << std::endl;
    }

    get_map_size(&socket, map);
    msg.sendMessage(&socket, "tna");
    sf::sleep(sf::milliseconds(500));
    msg.sendMessage(&socket, "mct");

    sf::RenderWindow window(sf::VideoMode(WIN_WIDTH, WIN_HEIGHT), "SFML Client");
    sf::View view = window.getDefaultView();

    const float moveSpeed = 300.0f;
    const float zoomFactor = 1.1f;
    sf::Clock clock;

    auto textures = loadResourceTextures();
    //gui.loadTextures();

    sf::SocketSelector selector;
    selector.add(socket);

    sf::Clock messageClock;
    const sf::Time messageInterval = sf::seconds(5);

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
                return 0;
            }
        }

        float deltaTime = clock.restart().asSeconds();
        gui.handle_view(&view, deltaTime, moveSpeed, zoomFactor);
        window.clear(sf::Color::White);
        window.setView(window.getDefaultView());
        fillScreenWithSprite(&window);

        window.setView(view);

        if (selector.wait(sf::milliseconds(100))) {
            if (selector.isReady(socket)) {
                char buffer[1000000];
                std::size_t received;
                sf::Socket::Status receiveStatus = socket.receive(buffer, sizeof(buffer) - 1, received);
                if (receiveStatus == sf::Socket::Done) {
                    buffer[received] = '\0';
                    std::istringstream iss(buffer);
                    std::vector<std::string> messages;
                    std::string msg;
                    while (std::getline(iss, msg)) {
                        if (!msg.empty()) {
                            messages.push_back(msg);
                        }
                    }
                    handle_server_messages(messages, map, textures, &teamData, players, eggs, broadcast);
                } else if (receiveStatus != sf::Socket::NotReady) {
                    window.close();
                    return 0;
                }
            }
        }
        if (map->start_ppo == true) {
            if (messageClock.getElapsedTime() >= messageInterval) {
                msg.sendMessage(&socket, "ppo", players);
                sf::sleep(sf::milliseconds(500));
                msg.sendMessage(&socket, "pin", players);
                sf::sleep(sf::milliseconds(500));
                msg.sendMessage(&socket, "plv", players);
                sf::sleep(sf::milliseconds(500));
                messageClock.restart();
            }
        }

        if (map->width > 0 && map->height > 0) {
            gui.draw_map(&window, map, textures, players, eggs, broadcast);
        }
        window.display();
    }
    return 0;
}

```

#### <span style="font-family: 'Times New Roman', Times, serif; color:orange;">*draw_map.cpp (the graphical module part)*

This file contains the continuous of the gui_main.cpp functions also part of the gui.hpp

```
#include "gui.hpp"
#include <iostream>

GUI::GUI() {}

void GUI::handle_view(sf::View* view, float deltaTime, float moveSpeed, float zoomFactor) {
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
        view->move(0, -moveSpeed * deltaTime);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
        view->move(0, moveSpeed * deltaTime);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
        view->move(-moveSpeed * deltaTime, 0);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
        view->move(moveSpeed * deltaTime, 0);
    }

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Add)) {
        view->zoom(1.0f / zoomFactor);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Subtract)) {
        view->zoom(zoomFactor);
    }
}

void GUI::render_broadcast(sf::RenderWindow* window, const Broadcast& broadcast, const sf::Font& font) {
    if (broadcast.timer.getElapsedTime().asSeconds() < 3.0f) {
        sf::Text broadcastText;
        broadcastText.setFont(font);
        broadcastText.setString(broadcast.message);
        broadcastText.setCharacterSize(200);
        broadcastText.setFillColor(sf::Color::White);
        broadcastText.setPosition(0, 0);

        window->draw(broadcastText);
        broadcastAnimation.update();
        broadcastAnimation.draw(window);
    }
}


void GUI::draw_player(sf::RenderWindow* window, const std::vector<PlayerData>& players, mapdata_t* mapData) {

    sf::Font font;
    sf::Text playerInfoText;

    float offsetX = WIN_WIDTH / 2 - (mapData->width * (tileSize + spacing)) / 4;
    float offsetY = WIN_HEIGHT / 2 - (mapData->height * (tileSize + spacing)) / 4;

    if (!font.loadFromFile("font/arial.ttf")) {
        std::cerr << "Failed to load font" << std::endl;
        return;
    }

    playerInfoText.setFont(font);
    playerInfoText.setCharacterSize(30);
    playerInfoText.setFillColor(sf::Color::Black);
    playerInfoText.setString("Test Text");
    playerInfoText.setPosition(10, 10);

    sf::Vector2i mousePos = sf::Mouse::getPosition(*window);
    sf::Vector2f worldPos = window->mapPixelToCoords(mousePos);
    bool playerHovered = false;

    sf::RectangleShape infoBackground(sf::Vector2f(250, 400));
    infoBackground.setFillColor(sf::Color(200, 200, 200, 150));

    for (const auto& player : players) {
        float tileX = (player.x - player.y) * (tileSize + spacing) / 2 + offsetX + 175;
        float tileY = (player.x + player.y) * (tileSize + spacing) / 4 + offsetY + 25;

        sf::Sprite spriteCopy = player.sprite;
        spriteCopy.setScale(3.5f, 3.5f);
        spriteCopy.setPosition(tileX, tileY);
        window->draw(spriteCopy);

        sf::FloatRect eggBounds = spriteCopy.getGlobalBounds();

        if (eggBounds.contains(worldPos)) {
            playerInfoText.setString("ID: " + std::to_string(player.id) + 
                                     "\nTeam: " + player.teamName + 
                                     "\nLevel: " + std::to_string(player.level) +
                                     "\nResources:" +
                                     "\nFood: " + std::to_string(player.inventory.food) +
                                     "\nLinemate: " + std::to_string(player.inventory.linemate) +
                                     "\nDeraumere: " + std::to_string(player.inventory.deraumere) +
                                     "\nSibur: " + std::to_string(player.inventory.sibur) + 
                                     "\nMendiane: " + std::to_string(player.inventory.mendiane) + 
                                     "\nPhiras: " + std::to_string(player.inventory.phiras) + 
                                     "\nThystame: " + std::to_string(player.inventory.thystame));
            playerInfoText.setPosition(worldPos.x + 20, worldPos.y + 20);
            infoBackground.setPosition(worldPos.x + 10, worldPos.y + 10);
            playerHovered = true;
        }
    }

    if (playerHovered) {
        window->draw(infoBackground);
        window->draw(playerInfoText);
    }
}

void GUI::draw_egg(sf::RenderWindow* window, mapdata_t* mapData, const std::vector<Egg>& eggs) {

        float offsetX = WIN_WIDTH / 2 - (mapData->width * (tileSize + spacing)) / 4;
        float offsetY = WIN_HEIGHT / 2 - (mapData->height * (tileSize + spacing)) / 4;

        sf::Font font;
        sf::Text eggInfoText;
         if (!font.loadFromFile("font/arial.ttf")) {
            std::cerr << "Failed to load font" << std::endl;
            return;
        }

        eggInfoText.setFont(font);
        eggInfoText.setCharacterSize(30);
        eggInfoText.setFillColor(sf::Color::Black);
        eggInfoText.setString("Test Text");
        eggInfoText.setPosition(10, 10);

        sf::Vector2i mousePos = sf::Mouse::getPosition(*window);
        sf::Vector2f worldPos = window->mapPixelToCoords(mousePos);
        bool eggHovered = false;

        sf::RectangleShape infoBackground(sf::Vector2f(200, 300));
        infoBackground.setFillColor(sf::Color(200, 200, 200, 150));

        for (const auto& egg : eggs) {
        float tileX = (egg.x - egg.y) * (tileSize + spacing) / 2 + offsetX + 175;
        float tileY = (egg.x + egg.y) * (tileSize + spacing) / 4 + offsetY + 25;

        sf::Sprite eggSprite = egg.sprite;
        eggSprite.setScale(0.2f, 0.2f);
        eggSprite.setPosition(tileX, tileY);
        window->draw(eggSprite);

        sf::FloatRect eggBounds = eggSprite.getGlobalBounds();

        if (eggBounds.contains(worldPos)) {
            eggInfoText.setString("Egg ID: " + std::to_string(egg.eggId) +
                                     "\nPlayer ID: " + std::to_string(egg.playerId) +
                                     "\nPoitions: " +
                                     "\nX: " + std::to_string(egg.x) +
                                     "\nY: " + std::to_string(egg.y));
            eggInfoText.setPosition(worldPos.x + 20, worldPos.y + 20);
            infoBackground.setPosition(worldPos.x + 10, worldPos.y + 10);
            eggHovered = true;
        }
    }
    if (eggHovered) {
        window->draw(infoBackground);
        window->draw(eggInfoText);
    }
}

void GUI::draw_map(sf::RenderWindow* window, mapdata_t* map, 
                  const std::unordered_map<std::string, sf::Texture>& textures,
                  const std::vector<PlayerData>& players, 
                  const std::vector<Egg>& eggs, 
                  const Broadcast& broadcast) {
    
    sf::Texture tileTexture;
    sf::Font font;
        if (!font.loadFromFile("font/arial.ttf")) {
        std::cerr << "Failed to load font" << std::endl;
        return;
    }
    if (!tileTexture.loadFromFile("images/tiles4.png")) {
        std::cerr << "Failed to load tile texture" << std::endl;
        return;
    }

    float offsetX = WIN_WIDTH / 2 - (map->width * (tileSize + spacing)) / 4;
    float offsetY = WIN_HEIGHT / 2 - (map->height * (tileSize + spacing)) / 4;

    for (int y = 0; y < map->height; ++y) {
        for (int x = 0; x < map->width; ++x) {
            Tile tile(tileTexture,
                (x - y) * (tileSize + spacing) / 2 + offsetX,
                (x + y) * (tileSize + spacing) / 4 + offsetY);
            tile.setResources(map->tiles[y][x].resources, textures);

            tile.draw(*window);
        }
    }

    draw_player(window, players, map);
    draw_egg(window, map, eggs);
    render_broadcast(window, broadcast, font);
}
```

#### <span style="font-family: 'Times New Roman', Times, serif; color:orange;">*parse_commands.hpp (commandParser module part)*

```
#include "header.hpp"
#include "broadcast.hpp"

class CommandParser {

public:
    CommandParser() = default;
    std::vector<PlayerData>::iterator findPlayerById(std::vector<PlayerData>& players, int id);
    void log_tile_resources(int x, int y, const Resources& resources);
    void update_player_orientation(PlayerData& player, int newOrientation, int x, int y);
    void parse_pbc_message(const std::string& message);
    void parse_pic_message(const std::string& message);
    void parse_bct_message(const std::string& message, mapdata_t* mapData);
    void parse_pnw_message(const std::string& message, std::vector<PlayerData>& players,
    const std::unordered_map<std::string, sf::Texture>& textures, mapdata_t *map);
    void parse_tna_message(const std::string& message, TeamData* teamData);
    void parse_pin_message(const std::string& command, std::vector<PlayerData>& players);
    void parse_pdi_command(const std::string& command, std::vector<PlayerData>& players, mapdata_t *map);
    void parse_enw_command(const std::string& command, std::vector<Egg>& eggs,
    const std::unordered_map<std::string, sf::Texture>& textures);
    void parse_pbc_command(const std::string& command, std::vector<PlayerData>& players, Broadcast& broadcast);
    void parse_pic_command(const std::string& command, std::vector<PlayerData>& players);
    void parse_edi_command(const std::string& command, std::vector<Egg>& eggs);
    void parse_plv_message(const std::string& message, std::vector<PlayerData>& players);
    void parse_ppo_message(const std::string& message, std::vector<PlayerData>& players);
};
```

#### <span style="font-family: 'Times New Roman', Times, serif; color:orange;">*parse_commands.cpp (commandParser module part)*

```
#include "parse_commands.hpp"

static BroadcastAnimation broadcastAnimation;

void CommandParser::log_tile_resources(int x, int y, const Resources& resources) {
    std::cout << "Tile (" << x << ", " << y << ") Resources:\n"
              << "  Food: " << resources.food << "\n"
              << "  Linemate: " << resources.linemate << "\n"
              << "  Deraumere: " << resources.deraumere << "\n"
              << "  Sibur: " << resources.sibur << "\n"
              << "  Mendiane: " << resources.mendiane << "\n"
              << "  Phiras: " << resources.phiras << "\n"
              << "  Thystame: " << resources.thystame << "\n";
}

void CommandParser::update_player_orientation(PlayerData& player, int newOrientation, int x, int y) {
    player.orientation = newOrientation;
    player.x = x;
    player.y = y;
    player.sprite.setPosition(static_cast<float>(x * SPRITE_SIZE), static_cast<float>(y * SPRITE_SIZE));

    switch (newOrientation) {
        case 1: player.sprite.setTextureRect(sf::IntRect(0, Down * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
        case 2: player.sprite.setTextureRect(sf::IntRect(0, Right * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
        case 3: player.sprite.setTextureRect(sf::IntRect(0, Up * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
        case 4: player.sprite.setTextureRect(sf::IntRect(0, Left * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
    }
}

std::vector<PlayerData>::iterator CommandParser::findPlayerById(std::vector<PlayerData>& players, int id) {
    return std::find_if(players.begin(), players.end(), [id](const PlayerData& player) {
        return player.id == id;
    });
}

void CommandParser::parse_pbc_message(const std::string& message) {
    std::cout << "Broadcast message: " << message << std::endl;
}

void CommandParser::parse_pic_message(const std::string& message) {
    std::cout << "Incantation started: " << message << std::endl;
}


void CommandParser::parse_bct_message(const std::string& message, mapdata_t* mapData) {
    std::istringstream stream(message);
    std::string command;
    int x, y;
    Resources resources;
    std::cout << "Received message in parse_bct_message: " << message << std::endl;

    stream >> command >> x >> y >> resources.food >> resources.linemate >> resources.deraumere
        >> resources.sibur >> resources.mendiane >> resources.phiras >> resources.thystame;

    if (command == "bct" && x >= 0 && x < mapData->width && y >= 0 && y < mapData->height) {
        mapData->tiles[y][x].resources = resources;
        log_tile_resources(x, y, resources);
    }
}

void CommandParser::parse_pnw_message(const std::string& message, std::vector<PlayerData>& players, const std::unordered_map<std::string, sf::Texture>& textures, mapdata_t *map) {
    std::istringstream stream(message);
    std::string command;
    int id, x, y, orientation, level;
    std::string teamName;

    stream >> command >> id >> x >> y >> orientation >> level >> teamName;

    if (command == "pnw") {
        PlayerData newPlayer;
        newPlayer.id = id;
        newPlayer.x = x;
        newPlayer.y = y;
        newPlayer.orientation = orientation;
        newPlayer.level = level;
        newPlayer.teamName = teamName;
        newPlayer.sprite.setTexture(textures.at("player"));
        std::cout << newPlayer.x <<  newPlayer.y << std::endl;

        switch (orientation) {
            case 1: newPlayer.sprite.setTextureRect(sf::IntRect(0, Down * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
            case 2: newPlayer.sprite.setTextureRect(sf::IntRect(0, Right * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
            case 3: newPlayer.sprite.setTextureRect(sf::IntRect(0, Up * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
            case 4: newPlayer.sprite.setTextureRect(sf::IntRect(0, Left * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
        }
        players.push_back(newPlayer);
        map->start_ppo = true;
    }
}

void CommandParser::parse_tna_message(const std::string& message, TeamData* teamData) {
    std::istringstream stream(message);
    std::string command, teamName;

    stream >> command;
    if (command == "tna") {
        while (stream >> teamName) {
            teamData->teamNames.push_back(teamName);
        }
    }
    std::cout << "Team Names:\n";
    for (const std::string& name : teamData->teamNames) {
        std::cout << name << "\n";
    }
}

void CommandParser::parse_pin_message(const std::string& command, std::vector<PlayerData>& players) {
    std::istringstream iss(command);
    std::string token;
    std::vector<std::string> tokens;

    while (iss >> token) {
        tokens.push_back(token);
    }

    int id = std::stoi(tokens[1]);
    int x = std::stoi(tokens[2]);
    int y = std::stoi(tokens[3]);

    Resources inventory;
    inventory.food = std::stoi(tokens[4]);
    inventory.linemate = std::stoi(tokens[5]);
    inventory.deraumere = std::stoi(tokens[6]);
    inventory.sibur = std::stoi(tokens[7]);
    inventory.mendiane = std::stoi(tokens[8]);
    inventory.phiras = std::stoi(tokens[9]);
    inventory.thystame = std::stoi(tokens[10]);

    auto it = findPlayerById(players, id);

    if (it != players.end()) {
        it->x = x;
        it->y = y;
        it->inventory = inventory;
    } else {
        PlayerData newPlayer;
        newPlayer.id = id;
        newPlayer.x = x;
        newPlayer.y = y;
        newPlayer.inventory = inventory;
        players.push_back(newPlayer);
    }
    for (const auto& player : players) {
        std::cout << "Player ID: " << player.id << std::endl;
        std::cout << "Position: (" << player.x << ", " << player.y << ")" << std::endl;
        std::cout << "Resources: " << std::endl;
        std::cout << "  Food: " << player.inventory.food << std::endl;
        std::cout << "  Linemate: " << player.inventory.linemate << std::endl;
        std::cout << "  Deraumere: " << player.inventory.deraumere << std::endl;
        std::cout << "  Sibur: " << player.inventory.sibur << std::endl;
        std::cout << "  Mendiane: " << player.inventory.mendiane << std::endl;
        std::cout << "  Phiras: " << player.inventory.phiras << std::endl;
        std::cout << "  Thystame: " << player.inventory.thystame << std::endl;
    }
}

void CommandParser::parse_pdi_command(const std::string& command, std::vector<PlayerData>& players, mapdata_t *map) {
    std::istringstream iss(command);
    std::string token;
    std::vector<std::string> tokens;

    while (iss >> token) {
        tokens.push_back(token);
    }

    if (tokens.size() != 2) {
        std::cerr << "Invalid pdi command format: " << command << std::endl;
        return;
    }

    int id = std::stoi(tokens[1]);

    auto it = findPlayerById(players, id);

    if (it != players.end()) {
        players.erase(it);
    }

    map->start_ppo = !players.empty();
    std::cout << "Players left: " << (map->start_ppo ? "Yes" : "No") << std::endl;
}

void CommandParser::parse_enw_command(const std::string& command, std::vector<Egg>& eggs, const std::unordered_map<std::string, sf::Texture>& textures) {
    std::istringstream iss(command);
    std::string token;
    std::vector<std::string> tokens;

    while (iss >> token) {
        tokens.push_back(token);
    }

    if (tokens.size() != 5) {
        std::cerr << "Invalid enw command format: " << command << std::endl;
        return;
    }

    int eggId = std::stoi(tokens[1]);
    int playerId = std::stoi(tokens[2]);
    int x = std::stoi(tokens[3]);
    int y = std::stoi(tokens[4]);

    Egg newEgg;
    newEgg.eggId = eggId;
    newEgg.playerId = playerId;
    newEgg.x = x;
    newEgg.y = y;

    auto it = textures.find("egg");
    if (it != textures.end()) {
        newEgg.sprite.setTexture(it->second);
    } else {
        std::cerr << "Failed to find egg texture in the texture map" << std::endl;
    }
    newEgg.sprite.setPosition(static_cast<float>(x), static_cast<float>(y));

    eggs.push_back(newEgg);
    for (const auto& egg : eggs) {
        std::cout << "Position: (" << egg.x << ", " << egg.y << ")" << std::endl;
    }
}

void CommandParser::parse_pbc_command(const std::string& command, std::vector<PlayerData>& players, Broadcast& broadcast) {
    std::istringstream iss(command);
    std::string token;
    std::vector<std::string> tokens;

    while (iss >> token) {
        tokens.push_back(token);
    }

    if (tokens.size() < 3) {
        std::cerr << "Invalid pbc command format: " << command << std::endl;
        return;
    }

    int playerId = std::stoi(tokens[1]);
    std::string message = tokens[2];

    for (size_t i = 3; i < tokens.size(); ++i) {
        message += " " + tokens[i];
    }

    for (auto& player : players) {
        if (player.id == playerId) {
            std::cout << "Broadcasting from player ID: " << player.id << std::endl;

            broadcastAnimation.startAnimation(message, sf::Vector2f(player.x, player.y));

            broadcast.message = "Broadcast: " + message;
            broadcast.timer.restart();
            break;
        }
    }
}


void CommandParser::parse_ppo_message(const std::string& message, std::vector<PlayerData>& players) {
    std::istringstream stream(message);
    std::string command;
    int id, x, y, orientation;

    stream >> command >> id >> x >> y >> orientation;

    if (command == "ppo") {
        std::cout <<id <<x <<y << orientation <<std::endl;
        for (auto& player : players) {
            if (player.id == id) {
                update_player_orientation(player, orientation, x, y);
                break;
            }
        }
    }
}


void CommandParser::parse_plv_message(const std::string& message, std::vector<PlayerData>& players) {
    std::istringstream stream(message);
    std::string command;
    int id, level;

    stream >> command >> id >> level;

    if (command == "plv") {
        std::cout << id << level <<std::endl;
        for (auto& player : players) {
            if (player.id == id) {
                player.level = level;
                break;
            }
        }
    }
}

void CommandParser::parse_pic_command(const std::string& command, std::vector<PlayerData>& players) {
    std::istringstream iss(command);
    std::string token;
    std::vector<std::string> tokens;

    while (iss >> token) {
        tokens.push_back(token);
    }

    if (tokens.size() < 5) {
        std::cerr << "Invalid pic command format: " << command << std::endl;
        return;
    }

    int x = std::stoi(tokens[1]);
    int y = std::stoi(tokens[2]);
    int level = std::stoi(tokens[3]);

    std::vector<int> playerIds;
    for (size_t i = 4; i < tokens.size(); ++i) {
        playerIds.push_back(std::stoi(tokens[i]));
    }

    for (auto& player : players) {
        if (std::find(playerIds.begin(), playerIds.end(), player.id) != playerIds.end()) {
            player.x = x;
            player.y = y;
            player.sprite.setPosition(static_cast<float>(x), static_cast<float>(y));
        }
    }

    std::cout << "Incantation started at (" << x << ", " << y << ") for level " << level << " with players: ";
    for (const auto& id : playerIds) {
        std::cout << id << " ";
    }
    std::cout << std::endl;
}

void CommandParser::parse_edi_command(const std::string& command, std::vector<Egg>& eggs) {
    std::istringstream iss(command);
    std::string token;
    std::vector<std::string> tokens;

    while (iss >> token) {
        tokens.push_back(token);
    }

    if (tokens.size() != 2) {
        std::cerr << "Invalid edi command format: " << command << std::endl;
        return;
    }

    int eggId = std::stoi(tokens[1]);

    auto it = std::remove_if(eggs.begin(), eggs.end(), [eggId](const Egg& egg) {
        return egg.eggId == eggId;
    });

    if (it != eggs.end()) {
        eggs.erase(it, eggs.end());
        std::cout << "Egg with ID " << eggId << " removed." << std::endl;
    } else {
        std::cerr << "Egg with ID " << eggId << " not found." << std::endl;
    }
}
```

#### <span style="font-family: 'Times New Roman', Times, serif; color:orange;">*send_commands.hpp (commandParser module part)*

```
#include "header.hpp"

#pragma once

class PlayerMessageSender {
public:
    PlayerMessageSender();
    ~PlayerMessageSender();
    void sendMessage(sf::TcpSocket* socket, const std::string& prefix, const std::vector<PlayerData>& players);
    void sendMessage(sf::TcpSocket* socket, const std::string& prefix);
};
```
#### <span style="font-family: 'Times New Roman', Times, serif; color:orange;">*send_commands.cpp (commandParser module part)*

```
#include "send_commands.hpp"

PlayerMessageSender::PlayerMessageSender() {}

PlayerMessageSender::~PlayerMessageSender() {}

void PlayerMessageSender::sendMessage(sf::TcpSocket* socket, const std::string& prefix, const std::vector<PlayerData>& players) {
    for (const auto& player : players) {
        std::string message = prefix + " " + std::to_string(player.id) + "\n";
        if (socket->send(message.c_str(), message.size()) != sf::Socket::Done) {
            std::cerr << "Failed to send message for player ID " << player.id << std::endl;
            return;
        }
    }
}

void PlayerMessageSender::sendMessage(sf::TcpSocket* socket, const std::string& prefix) {
        std::string message = prefix + "\n";
        if (socket->send(message.c_str(), message.size()) != sf::Socket::Done) {
            std::cerr << "Failed to send message: " << prefix << std::endl;
            return;
        }
}

```

#### <span style="font-family: 'Times New Roman', Times, serif; color:orange;">*tiles.hpp (graphical module part)*

```
/*
** EPITECH PROJECT, 2024
** zappy
** File description:
** header.hpp
*/
#include "header.hpp"

#ifndef TILE_HPP
  #define TILE_HPP

  class Tile {
public:
    Tile(sf::Texture& texture, float x, float y);

    void setResources(const Resources& res,
    const std::unordered_map<std::string, sf::Texture>& textures);
    bool isMouseOver(const sf::Vector2f& mousePos) const;
    void draw(sf::RenderWindow& window);
    const Resources& getResources() const;
    bool isClicked(const sf::Vector2f& mousePos, sf::Event event) const;
    
private:
    sf::Sprite sprite;
    sf::Vector2f position;
    Resources resources;
    std::vector<sf::Sprite> resourceSprites;
};

class Board {
public:
    Board();
    void setResources(const Resources& resources);
    void draw(sf::RenderWindow& window);

private:
    sf::Font font;
    sf::Text text;
    Resources resources;
};

#endif

```

#### <span style="font-family: 'Times New Roman', Times, serif; color:orange;">*tiles.cpp (graphical module part)*

```
#include "tiles.hpp"

Tile::Tile(sf::Texture& texture, float x, float y)
        : sprite(texture), position(x, y) {
        sprite.setPosition(position);
}

void Tile::setResources(const Resources& res, const std::unordered_map<std::string, sf::Texture>& textures) {
    resources = res;
    resourceSprites.clear();

    auto addResourceSprites = [&](const std::string& resourceName, int count) {
        for (int i = 0; i < count; ++i) {
            resourceSprites.emplace_back(textures.at(resourceName));
        }
    };

    if (res.food > 0) addResourceSprites("food", res.food);
    if (res.linemate > 0) addResourceSprites("linemate", res.linemate);
    if (res.deraumere > 0) addResourceSprites("deraumere", res.deraumere);
    if (res.sibur > 0) addResourceSprites("sibur", res.sibur);
    if (res.mendiane > 0) addResourceSprites("mendiane", res.mendiane);
    if (res.phiras > 0) addResourceSprites("phiras", res.phiras);
    if (res.thystame > 0) addResourceSprites("thystame", res.thystame);

    const int maxResourcesPerRow = 7;
    const float spacing = 30.0f;
    const float resourceSize = 10.0f;
    const float additionalOffsetX = 250.0f;

    for (size_t i = 0; i < resourceSprites.size(); ++i) {
        float offsetX = (i % maxResourcesPerRow) * (resourceSize + spacing) + additionalOffsetX; // Adjusted line
        float offsetY = (i / maxResourcesPerRow) * (resourceSize + spacing) + 100.0f;

        resourceSprites[i].setScale(0.5f, 0.5f); // Scale down the resource sprites
        resourceSprites[i].setPosition(position.x + offsetX, position.y + offsetY);
    }
}

void Tile::draw(sf::RenderWindow& window) {
    window.draw(sprite);
        for (auto& resourceSprite : resourceSprites) {
            window.draw(resourceSprite);
        }
}

bool Tile::isMouseOver(const sf::Vector2f& mousePos) const {
    return sprite.getGlobalBounds().contains(mousePos);
}

bool Tile::isClicked(const sf::Vector2f& mousePos, sf::Event event) const {
    return isMouseOver(mousePos) && event.type == sf::Event::MouseButtonPressed &&
    event.mouseButton.button == sf::Mouse::Left;
}

const Resources& Tile::getResources() const {
    return resources;
}

Board::Board() {
    if (!font.loadFromFile("font/arial.ttf")) {
        std::cerr << "Failed to load font" << std::endl;
    }
    text.setFont(font);
    text.setCharacterSize(14);
    text.setFillColor(sf::Color::Black);
}

void Board::setResources(const Resources& res) {
    resources = res;
    std::stringstream ss;
    ss << "Food: " << resources.food << "\n"
       << "Linemate: " << resources.linemate << "\n"
       << "Deraumere: " << resources.deraumere << "\n"
       << "Sibur: " << resources.sibur << "\n"
       << "Mendiane: " << resources.mendiane << "\n"
       << "Phiras: " << resources.phiras << "\n"
       << "Thystame: " << resources.thystame << "\n";
    text.setString(ss.str());
}

void Board::draw(sf::RenderWindow& window) {
    sf::RectangleShape background(sf::Vector2f(200, 150));
    background.setFillColor(sf::Color(200, 200, 200, 150));
    background.setPosition(10, 10);

    text.setPosition(20, 20);

    window.draw(background);
    window.draw(text);
}

```



## <span style="font-family: 'Times New Roman', Times, serif; color:green;">Folders

#### <span style="font-family: 'Times New Roman', Times, serif; color:green;">*/images/*

This is the folder that contains all the images, assets that has been used in the project.


#### <span style="font-family: 'Times New Roman', Times, serif; color:green;">*/fonter/ & /font/*

These two folders contain the fonts used to display text in the game world.

#### <span style="font-family: 'Times New Roman', Times, serif; color:green;">*/splash_screen*

This folder contains the images that has been used in the display_video function

