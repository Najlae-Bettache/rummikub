// BroadcastAnimation.hpp
#ifndef BROADCASTANIMATION_HPP
#define BROADCASTANIMATION_HPP

#include <SFML/Graphics.hpp>
#include <string>
#include <vector>

class BroadcastAnimation {
public:
    BroadcastAnimation();
    void startAnimation(const std::string& message, const sf::Vector2f& startPosition);
    void update();
    void draw(sf::RenderWindow *window);

private:
    struct AnimatedCharacter {
        sf::Text text;
        sf::Vector2f velocity;
        sf::Clock clock;
    };

    std::vector<AnimatedCharacter> characters;
    sf::Font font;
    sf::Vector2f startPosition;
    size_t currentCharIndex;
    sf::Clock animationClock;
};

#endif
