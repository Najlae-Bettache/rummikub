#include "parse_commands.hpp"

static BroadcastAnimation broadcastAnimation;

void CommandParser::log_tile_resources(int x, int y, const Resources& resources) {
    std::cout << "Tile (" << x << ", " << y << ") Resources:\n"
              << "  Food: " << resources.food << "\n"
              << "  Linemate: " << resources.linemate << "\n"
              << "  Deraumere: " << resources.deraumere << "\n"
              << "  Sibur: " << resources.sibur << "\n"
              << "  Mendiane: " << resources.mendiane << "\n"
              << "  Phiras: " << resources.phiras << "\n"
              << "  Thystame: " << resources.thystame << "\n";
}

void CommandParser::update_player_orientation(PlayerData& player, int newOrientation, int x, int y) {
    player.orientation = newOrientation;
    player.x = x;
    player.y = y;
    player.sprite.setPosition(static_cast<float>(x * SPRITE_SIZE), static_cast<float>(y * SPRITE_SIZE));

    switch (newOrientation) {
        case 1: player.sprite.setTextureRect(sf::IntRect(0, Down * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
        case 2: player.sprite.setTextureRect(sf::IntRect(0, Right * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
        case 3: player.sprite.setTextureRect(sf::IntRect(0, Up * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
        case 4: player.sprite.setTextureRect(sf::IntRect(0, Left * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
    }
}

std::vector<PlayerData>::iterator CommandParser::findPlayerById(std::vector<PlayerData>& players, int id) {
    return std::find_if(players.begin(), players.end(), [id](const PlayerData& player) {
        return player.id == id;
    });
}

void CommandParser::parse_pbc_message(const std::string& message) {
    std::cout << "Broadcast message: " << message << std::endl;
}

void CommandParser::parse_pic_message(const std::string& message) {
    std::cout << "Incantation started: " << message << std::endl;
}


void CommandParser::parse_bct_message(const std::string& message, mapdata_t* mapData) {
    std::istringstream stream(message);
    std::string command;
    int x, y;
    Resources resources;
    std::cout << "Received message in parse_bct_message: " << message << std::endl;

    stream >> command >> x >> y >> resources.food >> resources.linemate >> resources.deraumere
        >> resources.sibur >> resources.mendiane >> resources.phiras >> resources.thystame;

    if (command == "bct" && x >= 0 && x < mapData->width && y >= 0 && y < mapData->height) {
        mapData->tiles[y][x].resources = resources;
        log_tile_resources(x, y, resources);
    }
}

void CommandParser::parse_pnw_message(const std::string& message, std::vector<PlayerData>& players, const std::unordered_map<std::string, sf::Texture>& textures, mapdata_t *map) {
    std::istringstream stream(message);
    std::string command;
    int id, x, y, orientation, level;
    std::string teamName;

    stream >> command >> id >> x >> y >> orientation >> level >> teamName;

    if (command == "pnw") {
        PlayerData newPlayer;
        newPlayer.id = id;
        newPlayer.x = x;
        newPlayer.y = y;
        newPlayer.orientation = orientation;
        newPlayer.level = level;
        newPlayer.teamName = teamName;
        newPlayer.sprite.setTexture(textures.at("player"));
        std::cout << newPlayer.x <<  newPlayer.y << std::endl;

        switch (orientation) {
            case 1: newPlayer.sprite.setTextureRect(sf::IntRect(0, Down * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
            case 2: newPlayer.sprite.setTextureRect(sf::IntRect(0, Right * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
            case 3: newPlayer.sprite.setTextureRect(sf::IntRect(0, Up * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
            case 4: newPlayer.sprite.setTextureRect(sf::IntRect(0, Left * SPRITE_SIZE, SPRITE_SIZE, SPRITE_SIZE)); break;
        }
        players.push_back(newPlayer);
        map->start_ppo = true;
    }
}

void CommandParser::parse_tna_message(const std::string& message, TeamData* teamData) {
    std::istringstream stream(message);
    std::string command, teamName;

    stream >> command;
    if (command == "tna") {
        while (stream >> teamName) {
            teamData->teamNames.push_back(teamName);
        }
    }
    std::cout << "Team Names:\n";
    for (const std::string& name : teamData->teamNames) {
        std::cout << name << "\n";
    }
}

void CommandParser::parse_pin_message(const std::string& command, std::vector<PlayerData>& players) {
    std::istringstream iss(command);
    std::string token;
    std::vector<std::string> tokens;

    while (iss >> token) {
        tokens.push_back(token);
    }

    int id = std::stoi(tokens[1]);
    int x = std::stoi(tokens[2]);
    int y = std::stoi(tokens[3]);

    Resources inventory;
    inventory.food = std::stoi(tokens[4]);
    inventory.linemate = std::stoi(tokens[5]);
    inventory.deraumere = std::stoi(tokens[6]);
    inventory.sibur = std::stoi(tokens[7]);
    inventory.mendiane = std::stoi(tokens[8]);
    inventory.phiras = std::stoi(tokens[9]);
    inventory.thystame = std::stoi(tokens[10]);

    auto it = findPlayerById(players, id);

    if (it != players.end()) {
        it->x = x;
        it->y = y;
        it->inventory = inventory;
    } else {
        PlayerData newPlayer;
        newPlayer.id = id;
        newPlayer.x = x;
        newPlayer.y = y;
        newPlayer.inventory = inventory;
        players.push_back(newPlayer);
    }
    for (const auto& player : players) {
        std::cout << "Player ID: " << player.id << std::endl;
        std::cout << "Position: (" << player.x << ", " << player.y << ")" << std::endl;
        std::cout << "Resources: " << std::endl;
        std::cout << "  Food: " << player.inventory.food << std::endl;
        std::cout << "  Linemate: " << player.inventory.linemate << std::endl;
        std::cout << "  Deraumere: " << player.inventory.deraumere << std::endl;
        std::cout << "  Sibur: " << player.inventory.sibur << std::endl;
        std::cout << "  Mendiane: " << player.inventory.mendiane << std::endl;
        std::cout << "  Phiras: " << player.inventory.phiras << std::endl;
        std::cout << "  Thystame: " << player.inventory.thystame << std::endl;
    }
}

void CommandParser::parse_pdi_command(const std::string& command, std::vector<PlayerData>& players, mapdata_t *map) {
    std::istringstream iss(command);
    std::string token;
    std::vector<std::string> tokens;

    while (iss >> token) {
        tokens.push_back(token);
    }

    if (tokens.size() != 2) {
        std::cerr << "Invalid pdi command format: " << command << std::endl;
        return;
    }

    int id = std::stoi(tokens[1]);

    auto it = findPlayerById(players, id);

    if (it != players.end()) {
        players.erase(it);
    }

    map->start_ppo = !players.empty();
    std::cout << "Players left: " << (map->start_ppo ? "Yes" : "No") << std::endl;
}

void CommandParser::parse_enw_command(const std::string& command, std::vector<Egg>& eggs, const std::unordered_map<std::string, sf::Texture>& textures) {
    std::istringstream iss(command);
    std::string token;
    std::vector<std::string> tokens;

    while (iss >> token) {
        tokens.push_back(token);
    }

    if (tokens.size() != 5) {
        std::cerr << "Invalid enw command format: " << command << std::endl;
        return;
    }

    int eggId = std::stoi(tokens[1]);
    int playerId = std::stoi(tokens[2]);
    int x = std::stoi(tokens[3]);
    int y = std::stoi(tokens[4]);

    Egg newEgg;
    newEgg.eggId = eggId;
    newEgg.playerId = playerId;
    newEgg.x = x;
    newEgg.y = y;

    auto it = textures.find("egg");
    if (it != textures.end()) {
        newEgg.sprite.setTexture(it->second);
    } else {
        std::cerr << "Failed to find egg texture in the texture map" << std::endl;
    }
    newEgg.sprite.setPosition(static_cast<float>(x), static_cast<float>(y));

    eggs.push_back(newEgg);
    for (const auto& egg : eggs) {
        std::cout << "Position: (" << egg.x << ", " << egg.y << ")" << std::endl;
    }
}

void CommandParser::parse_pbc_command(const std::string& command, std::vector<PlayerData>& players, Broadcast& broadcast) {
    std::istringstream iss(command);
    std::string token;
    std::vector<std::string> tokens;

    while (iss >> token) {
        tokens.push_back(token);
    }

    if (tokens.size() < 3) {
        std::cerr << "Invalid pbc command format: " << command << std::endl;
        return;
    }

    int playerId = std::stoi(tokens[1]);
    std::string message = tokens[2];

    for (size_t i = 3; i < tokens.size(); ++i) {
        message += " " + tokens[i];
    }

    for (auto& player : players) {
        if (player.id == playerId) {
            std::cout << "Broadcasting from player ID: " << player.id << std::endl;

            broadcastAnimation.startAnimation(message, sf::Vector2f(player.x, player.y));

            broadcast.message = "Broadcast: " + message;
            broadcast.timer.restart();
            break;
        }
    }
}


void CommandParser::parse_ppo_message(const std::string& message, std::vector<PlayerData>& players) {
    std::istringstream stream(message);
    std::string command;
    int id, x, y, orientation;

    stream >> command >> id >> x >> y >> orientation;

    if (command == "ppo") {
        std::cout <<id <<x <<y << orientation <<std::endl;
        for (auto& player : players) {
            if (player.id == id) {
                update_player_orientation(player, orientation, x, y);
                break;
            }
        }
    }
}


void CommandParser::parse_plv_message(const std::string& message, std::vector<PlayerData>& players) {
    std::istringstream stream(message);
    std::string command;
    int id, level;

    stream >> command >> id >> level;

    if (command == "plv") {
        std::cout << id << level <<std::endl;
        for (auto& player : players) {
            if (player.id == id) {
                player.level = level;
                break;
            }
        }
    }
}

void CommandParser::parse_pic_command(const std::string& command, std::vector<PlayerData>& players) {
    std::istringstream iss(command);
    std::string token;
    std::vector<std::string> tokens;

    while (iss >> token) {
        tokens.push_back(token);
    }

    if (tokens.size() < 5) {
        std::cerr << "Invalid pic command format: " << command << std::endl;
        return;
    }

    int x = std::stoi(tokens[1]);
    int y = std::stoi(tokens[2]);
    int level = std::stoi(tokens[3]);

    std::vector<int> playerIds;
    for (size_t i = 4; i < tokens.size(); ++i) {
        playerIds.push_back(std::stoi(tokens[i]));
    }

    for (auto& player : players) {
        if (std::find(playerIds.begin(), playerIds.end(), player.id) != playerIds.end()) {
            player.x = x;
            player.y = y;
            player.sprite.setPosition(static_cast<float>(x), static_cast<float>(y));
        }
    }

    std::cout << "Incantation started at (" << x << ", " << y << ") for level " << level << " with players: ";
    for (const auto& id : playerIds) {
        std::cout << id << " ";
    }
    std::cout << std::endl;
}

void CommandParser::parse_edi_command(const std::string& command, std::vector<Egg>& eggs) {
    std::istringstream iss(command);
    std::string token;
    std::vector<std::string> tokens;

    while (iss >> token) {
        tokens.push_back(token);
    }

    if (tokens.size() != 2) {
        std::cerr << "Invalid edi command format: " << command << std::endl;
        return;
    }

    int eggId = std::stoi(tokens[1]);

    auto it = std::remove_if(eggs.begin(), eggs.end(), [eggId](const Egg& egg) {
        return egg.eggId == eggId;
    });

    if (it != eggs.end()) {
        eggs.erase(it, eggs.end());
        std::cout << "Egg with ID " << eggId << " removed." << std::endl;
    } else {
        std::cerr << "Egg with ID " << eggId << " not found." << std::endl;
    }
}
