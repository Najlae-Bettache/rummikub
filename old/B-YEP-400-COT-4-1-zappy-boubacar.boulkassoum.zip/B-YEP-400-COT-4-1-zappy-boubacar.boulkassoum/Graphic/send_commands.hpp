#include "header.hpp"

#pragma once

class PlayerMessageSender {
public:
    PlayerMessageSender();
    ~PlayerMessageSender();
    // void sendPpoMessage(sf::TcpSocket* socket, const std::vector<PlayerData>& players);
    // void sendPlvMessage(sf::TcpSocket* socket, const std::vector<PlayerData>& players);
    // void sendPinMessage(sf::TcpSocket* socket, const std::vector<PlayerData>& players);
    //void send_tna(sf::TcpSocket* socket);
    void sendMessage(sf::TcpSocket* socket, const std::string& prefix, const std::vector<PlayerData>& players);
    void sendMessage(sf::TcpSocket* socket, const std::string& prefix);
};
