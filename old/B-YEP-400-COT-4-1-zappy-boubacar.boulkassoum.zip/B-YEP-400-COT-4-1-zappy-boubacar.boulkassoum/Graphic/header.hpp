/*
** EPITECH PROJECT, 2024
** zappy
** File description:
** header.hpp
*/

#ifndef HEADER_HPP
    #define HEADER_HPP
    #include <SFML/Graphics.hpp>
    #include <SFML/Window.hpp>
    #include <SFML/Network.hpp>
    #include <iostream>
    #include <fstream>
    #include <vector>
    #include <string>
    #include <sstream>
    #include <utility>
    #include <random>
    #include <ctime>
    #include <unordered_map>
    #include <cstring>
    #include "broadcast.hpp"

    const int WIN_WIDTH = 1920;
    const int WIN_HEIGHT = 1080;
    const int SPRITE_SIZE = 64;
    const int WALK_SPEED = 2;


    using namespace sf;
    using namespace std;

    typedef struct {
        int food;
        int linemate;
        int deraumere;
        int sibur;
        int mendiane;
        int phiras;
        int thystame;
    } Resources;

    typedef struct {
        int id;
        int x;
        int y;
        int orientation;
        int level;
        Resources inventory;
        std::string teamName;
        sf::Sprite sprite;
    } PlayerData;

    typedef struct {
        int eggId;
        int playerId;
        int x;
        int y;
        sf::Sprite sprite;
    } Egg;

    typedef struct {
        std::vector<std::string> teamNames;
    } TeamData;


    typedef struct {
        Resources resources;
    } TileData;

    typedef struct {
        int width;
        int height;
        std::vector<std::vector<TileData>> tiles;
        bool start_ppo = false;
    } mapdata_t;

    typedef struct {
        std::string message;
        sf::Clock timer;
    } Broadcast;

    enum Orientation {
        Up = 0,
        Right = 1,
        Down = 2,
        Left = 3
    };

void fillScreenWithSprite(sf::RenderWindow *window);
void parse_pic_message(const std::string& message);
void parse_pbc_message(const std::string& message);
int gui_server(const std::string&, unsigned short ,  mapdata_t *map);
void parse_tna_message(const std::string& message, TeamData* teamData);
void parse_plv_message(const std::string& message, std::vector<PlayerData>& players);
void parse_ppo_message(const std::string& message, std::vector<PlayerData>& players);
void update_player_orientation(PlayerData& player, int newOrientation, int x, int y);
void parse_pin_message(const std::string& command, std::vector<PlayerData>& players);
void parse_pnw_message(const std::string& message, std::vector<PlayerData>& players,
const std::unordered_map<std::string, sf::Texture>& textures, mapdata_t *map);
void parse_bct_message(const std::string& message, mapdata_t* mapData);
void handle_view(sf::View *, float, const float, const float);
void draw_map(sf::RenderWindow* window, mapdata_t* mapData,
const std::unordered_map<std::string, sf::Texture>& textures, const std::vector<PlayerData>& players, const std::vector<Egg>& eggs, Broadcast& broadcast);
std::vector<PlayerData>::iterator findPlayerById(std::vector<PlayerData>& players, int id);
void parse_pdi_command(const std::string& command, std::vector<PlayerData>& players, mapdata_t *map);
void parse_enw_command(const std::string& command, std::vector<Egg>& eggs,
const std::unordered_map<std::string, sf::Texture>& textures);
void parse_pbc_command(const std::string& command, std::vector<PlayerData>& players, Broadcast& broadcast);
void parse_pic_command(const std::string& command, std::vector<PlayerData>& players);
void parse_edi_command(const std::string& command, std::vector<Egg>& eggs);
#endif