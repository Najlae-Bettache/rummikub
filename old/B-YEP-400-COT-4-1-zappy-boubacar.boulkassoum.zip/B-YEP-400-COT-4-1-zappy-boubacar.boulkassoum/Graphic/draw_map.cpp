#include "gui.hpp"
#include <iostream>

GUI::GUI() {}

void GUI::handle_view(sf::View* view, float deltaTime, float moveSpeed, float zoomFactor) {
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
        view->move(0, -moveSpeed * deltaTime);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
        view->move(0, moveSpeed * deltaTime);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
        view->move(-moveSpeed * deltaTime, 0);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
        view->move(moveSpeed * deltaTime, 0);
    }

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Add)) {
        view->zoom(1.0f / zoomFactor);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Subtract)) {
        view->zoom(zoomFactor);
    }
}

void GUI::render_broadcast(sf::RenderWindow* window, const Broadcast& broadcast, const sf::Font& font) {
    if (broadcast.timer.getElapsedTime().asSeconds() < 3.0f) {
        sf::Text broadcastText;
        broadcastText.setFont(font);
        broadcastText.setString(broadcast.message);
        broadcastText.setCharacterSize(200);
        broadcastText.setFillColor(sf::Color::White);
        broadcastText.setPosition(0, 0);

        window->draw(broadcastText);
        broadcastAnimation.update();
        broadcastAnimation.draw(window);
    }
}


void GUI::draw_player(sf::RenderWindow* window, const std::vector<PlayerData>& players, mapdata_t* mapData) {

    sf::Font font;
    sf::Text playerInfoText;

    float offsetX = WIN_WIDTH / 2 - (mapData->width * (tileSize + spacing)) / 4;
    float offsetY = WIN_HEIGHT / 2 - (mapData->height * (tileSize + spacing)) / 4;

    if (!font.loadFromFile("font/arial.ttf")) {
        std::cerr << "Failed to load font" << std::endl;
        return;
    }

    playerInfoText.setFont(font);
    playerInfoText.setCharacterSize(30);
    playerInfoText.setFillColor(sf::Color::Black);
    playerInfoText.setString("Test Text");
    playerInfoText.setPosition(10, 10);

    sf::Vector2i mousePos = sf::Mouse::getPosition(*window);
    sf::Vector2f worldPos = window->mapPixelToCoords(mousePos);
    bool playerHovered = false;

    sf::RectangleShape infoBackground(sf::Vector2f(250, 400));
    infoBackground.setFillColor(sf::Color(200, 200, 200, 150));

    for (const auto& player : players) {
        float tileX = (player.x - player.y) * (tileSize + spacing) / 2 + offsetX + 175;
        float tileY = (player.x + player.y) * (tileSize + spacing) / 4 + offsetY + 25;

        sf::Sprite spriteCopy = player.sprite;
        spriteCopy.setScale(3.5f, 3.5f);
        spriteCopy.setPosition(tileX, tileY);
        window->draw(spriteCopy);

        sf::FloatRect eggBounds = spriteCopy.getGlobalBounds();

        if (eggBounds.contains(worldPos)) {
            playerInfoText.setString("ID: " + std::to_string(player.id) + 
                                     "\nTeam: " + player.teamName + 
                                     "\nLevel: " + std::to_string(player.level) +
                                     "\nResources:" +
                                     "\nFood: " + std::to_string(player.inventory.food) +
                                     "\nLinemate: " + std::to_string(player.inventory.linemate) +
                                     "\nDeraumere: " + std::to_string(player.inventory.deraumere) +
                                     "\nSibur: " + std::to_string(player.inventory.sibur) + 
                                     "\nMendiane: " + std::to_string(player.inventory.mendiane) + 
                                     "\nPhiras: " + std::to_string(player.inventory.phiras) + 
                                     "\nThystame: " + std::to_string(player.inventory.thystame));
            playerInfoText.setPosition(worldPos.x + 20, worldPos.y + 20);
            infoBackground.setPosition(worldPos.x + 10, worldPos.y + 10);
            playerHovered = true;
        }
    }

    if (playerHovered) {
        window->draw(infoBackground);
        window->draw(playerInfoText);
    }
}

void GUI::draw_egg(sf::RenderWindow* window, mapdata_t* mapData, const std::vector<Egg>& eggs) {

        float offsetX = WIN_WIDTH / 2 - (mapData->width * (tileSize + spacing)) / 4;
        float offsetY = WIN_HEIGHT / 2 - (mapData->height * (tileSize + spacing)) / 4;

        sf::Font font;
        sf::Text eggInfoText;
         if (!font.loadFromFile("font/arial.ttf")) {
            std::cerr << "Failed to load font" << std::endl;
            return;
        }

        eggInfoText.setFont(font);
        eggInfoText.setCharacterSize(30);
        eggInfoText.setFillColor(sf::Color::Black);
        eggInfoText.setString("Test Text");
        eggInfoText.setPosition(10, 10);

        sf::Vector2i mousePos = sf::Mouse::getPosition(*window);
        sf::Vector2f worldPos = window->mapPixelToCoords(mousePos);
        bool eggHovered = false;

        sf::RectangleShape infoBackground(sf::Vector2f(200, 300));
        infoBackground.setFillColor(sf::Color(200, 200, 200, 150));

        for (const auto& egg : eggs) {
        float tileX = (egg.x - egg.y) * (tileSize + spacing) / 2 + offsetX + 175;
        float tileY = (egg.x + egg.y) * (tileSize + spacing) / 4 + offsetY + 25;

        sf::Sprite eggSprite = egg.sprite;
        eggSprite.setScale(0.2f, 0.2f);
        eggSprite.setPosition(tileX, tileY);
        window->draw(eggSprite);

        sf::FloatRect eggBounds = eggSprite.getGlobalBounds();

        if (eggBounds.contains(worldPos)) {
            eggInfoText.setString("Egg ID: " + std::to_string(egg.eggId) +
                                     "\nPlayer ID: " + std::to_string(egg.playerId) +
                                     "\nPoitions: " +
                                     "\nX: " + std::to_string(egg.x) +
                                     "\nY: " + std::to_string(egg.y));
            eggInfoText.setPosition(worldPos.x + 20, worldPos.y + 20);
            infoBackground.setPosition(worldPos.x + 10, worldPos.y + 10);
            eggHovered = true;
        }
    }
    if (eggHovered) {
        window->draw(infoBackground);
        window->draw(eggInfoText);
    }
}

void GUI::draw_map(sf::RenderWindow* window, mapdata_t* map, 
                  const std::unordered_map<std::string, sf::Texture>& textures,
                  const std::vector<PlayerData>& players, 
                  const std::vector<Egg>& eggs, 
                  const Broadcast& broadcast) {
    
    sf::Texture tileTexture;
    sf::Font font;
        if (!font.loadFromFile("font/arial.ttf")) {
        std::cerr << "Failed to load font" << std::endl;
        return;
    }
    if (!tileTexture.loadFromFile("images/tiles4.png")) {
        std::cerr << "Failed to load tile texture" << std::endl;
        return;
    }

    float offsetX = WIN_WIDTH / 2 - (map->width * (tileSize + spacing)) / 4;
    float offsetY = WIN_HEIGHT / 2 - (map->height * (tileSize + spacing)) / 4;

    for (int y = 0; y < map->height; ++y) {
        for (int x = 0; x < map->width; ++x) {
            Tile tile(tileTexture,
                (x - y) * (tileSize + spacing) / 2 + offsetX,
                (x + y) * (tileSize + spacing) / 4 + offsetY);
            tile.setResources(map->tiles[y][x].resources, textures);

            tile.draw(*window);
        }
    }

    draw_player(window, players, map);
    draw_egg(window, map, eggs);
    render_broadcast(window, broadcast, font);
}