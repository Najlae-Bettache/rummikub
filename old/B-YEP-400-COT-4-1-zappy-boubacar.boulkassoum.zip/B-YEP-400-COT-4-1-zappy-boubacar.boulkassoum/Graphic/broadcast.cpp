// BroadcastAnimation.cpp
#include "broadcast.hpp"

BroadcastAnimation::BroadcastAnimation() : currentCharIndex(0) {
    if (!font.loadFromFile("font/arial.ttf")) {
        throw std::runtime_error("Failed to load font");
    }
}

void BroadcastAnimation::startAnimation(const std::string& message, const sf::Vector2f& startPosition) {
    this->startPosition = startPosition;
    currentCharIndex = 0;
    characters.clear();
    animationClock.restart();

    for (char c : message) {
        AnimatedCharacter animChar;
        animChar.text.setFont(font);
        animChar.text.setString(c);
        animChar.text.setPosition(startPosition);
        animChar.velocity = sf::Vector2f(0, -50);
        characters.push_back(animChar);
    }
}

void BroadcastAnimation::update() {
    float deltaTime = animationClock.restart().asSeconds();

    for (auto& animChar : characters) {
        if (animChar.clock.getElapsedTime().asSeconds() > 0.1f * currentCharIndex) {
            animChar.text.move(animChar.velocity * deltaTime);
            animChar.text.setFillColor(sf::Color(255, 255, 255, 255 - static_cast<int>(animChar.clock.getElapsedTime().asSeconds() * 255 / 2))); // Fade out over 2 seconds
        }
    }

    if (currentCharIndex < characters.size() && characters[currentCharIndex].clock.getElapsedTime().asSeconds() > 0.1f) {
        characters[currentCharIndex].clock.restart();
        currentCharIndex++;
    }
}

void BroadcastAnimation::draw(sf::RenderWindow *window) {
    for (const auto& animChar : characters) {
        if (animChar.clock.getElapsedTime().asSeconds() < 2) {
            window->draw(animChar.text);
        }
    }
}
