#include "header.hpp"
#include "broadcast.hpp"

class CommandParser {

public:
    CommandParser() = default;
    std::vector<PlayerData>::iterator findPlayerById(std::vector<PlayerData>& players, int id);
    void log_tile_resources(int x, int y, const Resources& resources);
    void update_player_orientation(PlayerData& player, int newOrientation, int x, int y);
    void parse_pbc_message(const std::string& message);
    void parse_pic_message(const std::string& message);
    void parse_bct_message(const std::string& message, mapdata_t* mapData);
    void parse_pnw_message(const std::string& message, std::vector<PlayerData>& players,
    const std::unordered_map<std::string, sf::Texture>& textures, mapdata_t *map);
    void parse_tna_message(const std::string& message, TeamData* teamData);
    void parse_pin_message(const std::string& command, std::vector<PlayerData>& players);
    void parse_pdi_command(const std::string& command, std::vector<PlayerData>& players, mapdata_t *map);
    void parse_enw_command(const std::string& command, std::vector<Egg>& eggs,
    const std::unordered_map<std::string, sf::Texture>& textures);
    void parse_pbc_command(const std::string& command, std::vector<PlayerData>& players, Broadcast& broadcast);
    void parse_pic_command(const std::string& command, std::vector<PlayerData>& players);
    void parse_edi_command(const std::string& command, std::vector<Egg>& eggs);
    void parse_plv_message(const std::string& message, std::vector<PlayerData>& players);
    void parse_ppo_message(const std::string& message, std::vector<PlayerData>& players);
};