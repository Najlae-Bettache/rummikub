#include "header.hpp"
#include "tiles.hpp"
#include "send_commands.hpp"
#include "parse_commands.hpp"
#include "gui.hpp"

CommandParser parser;
GUI gui;
std::unordered_map<std::string, sf::Texture> loadResourceTextures() {
    std::unordered_map<std::string, sf::Texture> textures;

    const std::vector<std::pair<std::string, std::string>> resourceFiles = {
        {"food", "images/food1.png"},
        {"linemate", "images/linemate.png"},
        {"deraumere", "images/deraumere.png"},
        {"sibur", "images/sibur.png"},
        {"mendiane", "images/mendiane.png"},
        {"phiras", "images/phiras.png"},
        {"thystame", "images/thystame.png"},
        {"player", "images/hero_sheet1.png"},
        {"egg", "images/egg.png"}
    };

    for (const auto& resource : resourceFiles) {
        sf::Texture texture;
        if (texture.loadFromFile(resource.second)) {
            textures[resource.first] = texture;
        } else {
            std::cerr << "Failed to load texture for " << resource.first << std::endl;
        }
    }

    return textures;
}

void handle_server_messages(const std::vector<std::string>& messages, mapdata_t* mapData,
    const std::unordered_map<std::string, sf::Texture>& textures,
    TeamData* teamData, std::vector<PlayerData>& players, std::vector<Egg>& eggs, Broadcast& broadcast) {
    for (const std::string& message : messages) {
        if (message.substr(0, 3) == "bct") {
            parser.parse_bct_message(message, mapData);
        } else if (message.substr(0, 3) == "tna") {
            parser.parse_tna_message(message, teamData);
        } else if (message.substr(0, 3) == "ppo") {
            parser.parse_ppo_message(message, players);
        } else if (message.substr(0, 3) == "plv") {
            parser.parse_plv_message(message, players);
        } else if (message.substr(0, 3) == "pnw") {
            parser.parse_pnw_message(message, players, textures, mapData);
        } else if (message.substr(0, 3) == "pin") {
            parser.parse_pin_message(message, players);
        } else if (message.substr(0, 3) == "pdi") {
            parser.parse_pdi_command(message, players, mapData);
        } else if (message.substr(0, 3) == "enw") {
            parser.parse_enw_command(message, eggs, textures);
        } else if (message.substr(0, 3) == "pbc") {
            parser.parse_pbc_command(message, players, broadcast);
        } else if (message.substr(0, 3) == "pic") {
            parser.parse_pic_command(message, players);
        } else if (message.substr(0, 3) == "edi") {
            parser.parse_edi_command(message, eggs);
        }
    }
}

void get_map_size(sf::TcpSocket* socket, mapdata_t* map) {
    std::string message = "msz\n";
    if (socket->send(message.c_str(), message.size()) != sf::Socket::Done) {
        std::cerr << "Failed to send msz message" << std::endl;
        return;
    }
    std::cout << "Sent: " << message << std::endl;

    char buffer[1000024];
    std::size_t received;
    sf::Socket::Status receiveStatus = socket->receive(buffer, sizeof(buffer) - 1, received);
    if (receiveStatus == sf::Socket::Done) {
        buffer[received] = '\0';
        std::cout << "Received from server in msz function: " << buffer << std::endl;

        std::istringstream iss(buffer);
        std::string command;
        iss >> command;
        if (command == "msz") {
            int x, y;
            iss >> x >> y;
            map->width = x;
            map->height = y;
            map->tiles.resize(map->height, std::vector<TileData>(map->width));
            std::cout << "Map size set to " << x << " x " << y << std::endl;
        }
    } else {
        std::cerr << "Failed to receive data from server" << std::endl;
    }
}

int gui_server(const std::string& machine, unsigned short port, mapdata_t* map) {
    sf::TcpSocket socket;
    sf::Socket::Status status = socket.connect(machine, port);
    TeamData teamData;
    Broadcast broadcast;
    PlayerMessageSender msg;
    std::vector<PlayerData> players;
    std::vector<Egg> eggs;
    if (status != sf::Socket::Done) {
        std::cerr << "Connection failed" << std::endl;
        return -1;
    }

    if (socket.send("GUI\n", 4) != sf::Socket::Done) {
        std::cerr << "Failed to send GUI message" << std::endl;
        return -1;
    }
    std::cout << "GUI message sent successfully" << std::endl;

    sf::sleep(sf::milliseconds(500));

    char initialBuffer[1024];
    std::size_t initialReceived;
    status = socket.receive(initialBuffer, sizeof(initialBuffer) - 1, initialReceived);
    if (status == sf::Socket::Done) {
        initialBuffer[initialReceived] = '\0';
        std::cout << "Initial server response: " << initialBuffer << std::endl;
    }

    get_map_size(&socket, map);
    msg.sendMessage(&socket, "tna");
    sf::sleep(sf::milliseconds(500));
    msg.sendMessage(&socket, "mct");

    sf::RenderWindow window(sf::VideoMode(WIN_WIDTH, WIN_HEIGHT), "SFML Client");
    sf::View view = window.getDefaultView();

    const float moveSpeed = 300.0f;
    const float zoomFactor = 1.1f;
    sf::Clock clock;

    auto textures = loadResourceTextures();
    //gui.loadTextures();

    sf::SocketSelector selector;
    selector.add(socket);

    sf::Clock messageClock;
    const sf::Time messageInterval = sf::seconds(5);

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
                return 0;
            }
        }

        float deltaTime = clock.restart().asSeconds();
        gui.handle_view(&view, deltaTime, moveSpeed, zoomFactor);
        window.clear(sf::Color::White);
        window.setView(window.getDefaultView());
        fillScreenWithSprite(&window);

        window.setView(view);

        if (selector.wait(sf::milliseconds(100))) {
            if (selector.isReady(socket)) {
                char buffer[1000000];
                std::size_t received;
                sf::Socket::Status receiveStatus = socket.receive(buffer, sizeof(buffer) - 1, received);
                if (receiveStatus == sf::Socket::Done) {
                    buffer[received] = '\0';
                    std::istringstream iss(buffer);
                    std::vector<std::string> messages;
                    std::string msg;
                    while (std::getline(iss, msg)) {
                        if (!msg.empty()) {
                            messages.push_back(msg);
                        }
                    }
                    handle_server_messages(messages, map, textures, &teamData, players, eggs, broadcast);
                } else if (receiveStatus != sf::Socket::NotReady) {
                    window.close();
                    return 0;
                }
            }
        }
        if (map->start_ppo == true) {
            if (messageClock.getElapsedTime() >= messageInterval) {
                msg.sendMessage(&socket, "ppo", players);
                sf::sleep(sf::milliseconds(500));
                msg.sendMessage(&socket, "pin", players);
                sf::sleep(sf::milliseconds(500));
                msg.sendMessage(&socket, "plv", players);
                sf::sleep(sf::milliseconds(500));
                messageClock.restart();
            }
        }

        if (map->width > 0 && map->height > 0) {
            gui.draw_map(&window, map, textures, players, eggs, broadcast);
        }
        window.display();
    }
    return 0;
}
