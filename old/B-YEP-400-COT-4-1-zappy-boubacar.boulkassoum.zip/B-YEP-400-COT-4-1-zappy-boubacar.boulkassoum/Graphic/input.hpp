/*
** EPITECH PROJECT, 2023
** C++game1_Udemy
** File description:
** input.hpp
*/
// #include "header.hpp"

// #ifndef INPUT_HPP
//     #define INPUT_HPP
// class Input
// {
//     struct Button
//     {
//         bool left, right, up, down, attack, escape;  
//     };

//     public:
//         Input();
//         ~Input();
//         void inputHandler(Event event, RenderWindow &window);
//         Button getButton(void) const;
        
//     private:
//         Button button;
// };
// enum Dir {Down, Right, Up, Left, Down_attack, Right_attack, Up_attack, Left_attack};
// struct Contenter {
//         Font font;
//         Text txt;
//         RenderWindow window;
//         Input input;
//         int posX = 1;
//         char temp[256];
//         Texture heroTexture;
//         Sprite heroSprite;
//         Clock heroAnimClock;
//         bool heroIdle = true;
//         bool needResetAnim = false;
// };

// #endif