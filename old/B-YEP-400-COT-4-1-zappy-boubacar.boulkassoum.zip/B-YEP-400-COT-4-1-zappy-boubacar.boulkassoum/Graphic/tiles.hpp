/*
** EPITECH PROJECT, 2024
** zappy
** File description:
** header.hpp
*/
#include "header.hpp"

#ifndef TILE_HPP
  #define TILE_HPP

  class Tile {
public:
    Tile(sf::Texture& texture, float x, float y);

    void setResources(const Resources& res,
    const std::unordered_map<std::string, sf::Texture>& textures);
    bool isMouseOver(const sf::Vector2f& mousePos) const;
    void draw(sf::RenderWindow& window);
    const Resources& getResources() const;
    bool isClicked(const sf::Vector2f& mousePos, sf::Event event) const;
    
private:
    sf::Sprite sprite;
    sf::Vector2f position;
    Resources resources;
    std::vector<sf::Sprite> resourceSprites;
};

class Board {
public:
    Board();
    void setResources(const Resources& resources);
    void draw(sf::RenderWindow& window);

private:
    sf::Font font;
    sf::Text text;
    Resources resources;
};

#endif
