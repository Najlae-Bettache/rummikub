#include "send_commands.hpp"

PlayerMessageSender::PlayerMessageSender() {}

PlayerMessageSender::~PlayerMessageSender() {}

void PlayerMessageSender::sendMessage(sf::TcpSocket* socket, const std::string& prefix, const std::vector<PlayerData>& players) {
    for (const auto& player : players) {
        std::string message = prefix + " " + std::to_string(player.id) + "\n";
        if (socket->send(message.c_str(), message.size()) != sf::Socket::Done) {
            std::cerr << "Failed to send message for player ID " << player.id << std::endl;
            return;
        }
    }
}

void PlayerMessageSender::sendMessage(sf::TcpSocket* socket, const std::string& prefix) {
        std::string message = prefix + "\n";
        if (socket->send(message.c_str(), message.size()) != sf::Socket::Done) {
            std::cerr << "Failed to send message: " << prefix << std::endl;
            return;
        }
}
