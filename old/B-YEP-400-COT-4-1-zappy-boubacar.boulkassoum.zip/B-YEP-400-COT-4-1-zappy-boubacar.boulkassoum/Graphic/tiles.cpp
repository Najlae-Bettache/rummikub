#include "tiles.hpp"

Tile::Tile(sf::Texture& texture, float x, float y)
        : sprite(texture), position(x, y) {
        sprite.setPosition(position);
}

void Tile::setResources(const Resources& res, const std::unordered_map<std::string, sf::Texture>& textures) {
    resources = res;
    resourceSprites.clear();

    auto addResourceSprites = [&](const std::string& resourceName, int count) {
        for (int i = 0; i < count; ++i) {
            resourceSprites.emplace_back(textures.at(resourceName));
        }
    };

    if (res.food > 0) addResourceSprites("food", res.food);
    if (res.linemate > 0) addResourceSprites("linemate", res.linemate);
    if (res.deraumere > 0) addResourceSprites("deraumere", res.deraumere);
    if (res.sibur > 0) addResourceSprites("sibur", res.sibur);
    if (res.mendiane > 0) addResourceSprites("mendiane", res.mendiane);
    if (res.phiras > 0) addResourceSprites("phiras", res.phiras);
    if (res.thystame > 0) addResourceSprites("thystame", res.thystame);

    const int maxResourcesPerRow = 7;
    const float spacing = 30.0f;
    const float resourceSize = 10.0f;
    const float additionalOffsetX = 250.0f;

    for (size_t i = 0; i < resourceSprites.size(); ++i) {
        float offsetX = (i % maxResourcesPerRow) * (resourceSize + spacing) + additionalOffsetX; // Adjusted line
        float offsetY = (i / maxResourcesPerRow) * (resourceSize + spacing) + 100.0f;

        resourceSprites[i].setScale(0.5f, 0.5f); // Scale down the resource sprites
        resourceSprites[i].setPosition(position.x + offsetX, position.y + offsetY);
    }
}

void Tile::draw(sf::RenderWindow& window) {
    window.draw(sprite);
        for (auto& resourceSprite : resourceSprites) {
            window.draw(resourceSprite);
        }
}

bool Tile::isMouseOver(const sf::Vector2f& mousePos) const {
    return sprite.getGlobalBounds().contains(mousePos);
}

bool Tile::isClicked(const sf::Vector2f& mousePos, sf::Event event) const {
    return isMouseOver(mousePos) && event.type == sf::Event::MouseButtonPressed &&
    event.mouseButton.button == sf::Mouse::Left;
}

const Resources& Tile::getResources() const {
    return resources;
}

Board::Board() {
    if (!font.loadFromFile("font/arial.ttf")) {
        std::cerr << "Failed to load font" << std::endl;
    }
    text.setFont(font);
    text.setCharacterSize(14);
    text.setFillColor(sf::Color::Black);
}

void Board::setResources(const Resources& res) {
    resources = res;
    std::stringstream ss;
    ss << "Food: " << resources.food << "\n"
       << "Linemate: " << resources.linemate << "\n"
       << "Deraumere: " << resources.deraumere << "\n"
       << "Sibur: " << resources.sibur << "\n"
       << "Mendiane: " << resources.mendiane << "\n"
       << "Phiras: " << resources.phiras << "\n"
       << "Thystame: " << resources.thystame << "\n";
    text.setString(ss.str());
}

void Board::draw(sf::RenderWindow& window) {
    sf::RectangleShape background(sf::Vector2f(200, 150));
    background.setFillColor(sf::Color(200, 200, 200, 150));
    background.setPosition(10, 10);

    text.setPosition(20, 20);

    window.draw(background);
    window.draw(text);
}

