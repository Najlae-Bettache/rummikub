#ifndef GUI_HPP
#define GUI_HPP

#include <SFML/Graphics.hpp>
#include "header.hpp"
#include "tiles.hpp"

class GUI {
public:
    GUI();
    void loadTextures();
    void handle_view(sf::View* view, float deltaTime, float moveSpeed, float zoomFactor);
    void draw_map(sf::RenderWindow* window, mapdata_t* map, 
                 const std::unordered_map<std::string, sf::Texture>& textures,
                 const std::vector<PlayerData>& players, 
                 const std::vector<Egg>& eggs, 
                 const Broadcast& broadcast);
    void draw_egg(sf::RenderWindow* window, mapdata_t* mapData, const std::vector<Egg>& eggs);
    void draw_player(sf::RenderWindow* window, const std::vector<PlayerData>& players, mapdata_t* mapData);
    void render_broadcast(sf::RenderWindow* window, const Broadcast& broadcast, const sf::Font& font);

private:
    mapdata_t* mapData;
    BroadcastAnimation broadcastAnimation;
    const int tileSize = 20;
    const int spacing = 500;

};

#endif 
