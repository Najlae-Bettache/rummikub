/*
** EPITECH PROJECT, 2023
** C++game1_Udemy
** File description:
** exemple.cpp
*/

#include "input.hpp"
#include "tiles.hpp"

void fillScreenWithSprite(sf::RenderWindow *window) {

    sf::Texture spriteTexture;
    if (!spriteTexture.loadFromFile("images/Water.jpg")) {
        std::cerr << "Failed to load sprite texture" << std::endl;
        return;
    }
    sf::Sprite sprite(spriteTexture);
    sf::Vector2u textureSize = sprite.getTexture()->getSize();
    int spriteWidth = textureSize.x;
    int spriteHeight = textureSize.y;

    for (int y = 0; y < WIN_HEIGHT; y += spriteHeight) {
        for (int x = 0; x < WIN_WIDTH; x += spriteWidth) {
            sprite.setPosition(static_cast<float>(x), static_cast<float>(y));
            window->draw(sprite);
        }
    }
}

void displayResources(sf::RenderWindow *window, const Resources& resources) {
    sf::Font font;
    if (!font.loadFromFile("font/arial.ttf")) {
        std::cerr << "Failed to load font" << std::endl;
        return;
    }

    sf::Text text;
    text.setFont(font);
    text.setCharacterSize(14);
    text.setFillColor(sf::Color::Black);

    std::stringstream ss;
    ss << "Food: " << resources.food << "\n"
       << "Linemate: " << resources.linemate << "\n"
       << "Deraumere: " << resources.deraumere << "\n"
       << "Sibur: " << resources.sibur << "\n"
       << "Mendiane: " << resources.mendiane << "\n"
       << "Phiras: " << resources.phiras << "\n"
       << "Thystame: " << resources.thystame << "\n";

    text.setString(ss.str());
    text.setPosition(300, 50);

    window->draw(text);
}


int main(int argc, char* argv[])
{
    mapdata_t mapData;
    if (argc != 5) {
        std::cerr << "Usage: " << argv[0] << " -p <port> -h <host>" << std::endl;
        return 84;
    }

    unsigned short port = 0;
    std::string host;

    for (int i = 1; i < argc; ++i) {
        if (std::string(argv[i]) == "-p" && i + 1 < argc) {
            port = static_cast<unsigned short>(std::stoi(argv[i + 1]));
            ++i;
        } else if (std::string(argv[i]) == "-h" && i + 1 < argc) {
            host = argv[i + 1];
            ++i;
        }
    }

    if (port == 0 || host.empty()) {
        std::cerr << "Invalid port or host" << std::endl;
        return 84;
    }

    return gui_server(host, port, &mapData);
}