/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Includes
*/

#pragma once

#include <netinet/in.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <sys/socket.h>
#include <signal.h>
#include <sys/queue.h>
#include <time.h>

typedef struct zappy_s zappy_t;
typedef struct inventory_s inventory_t;
typedef struct player_s player_t;
typedef struct position_s position_t;
typedef struct server_s server_t;
typedef struct client_s client_t;
typedef struct command_s command_t;
typedef struct look_s look_t;
typedef enum inv_s inv_t;
typedef enum mouvement_s mouvement_t;
typedef enum direction_s direction_t;
typedef enum statut_s statut_t;

int get_port(int, char **);
int get_width(int, char **);
int get_height(int, char **);
int get_nbclients(int, char **);
int get_freq(int, char **);
void get_teams(int, int, char **, zappy_t *);
void initialise_utils(int, char **, zappy_t *);
void initialise_map(zappy_t *);
void initialise_inventory(zappy_t *, inventory_t *);
void initialise_inventory_map(zappy_t *, inventory_t *);
void initialise_teams(int, char **, zappy_t *);
void initialise_players(int, zappy_t *);
void new_player(player_t *, char *, zappy_t *);
void new_egg(player_t *, char *, zappy_t *, position_t);
void random_position(zappy_t *, position_t *);
int random_mouvement(void);
void start_zappy(zappy_t *, server_t *);
void signal_handler(int);
void generate_ressources(zappy_t *);
void random_ressource(zappy_t *, inv_t);
void add_ressource_to_map(int, int, inventory_t, zappy_t *);
void initialise_connexion(int, char **, server_t *);
void clean_fd_set(fd_set *, server_t *);
void initialise_client(client_t *, struct sockaddr_in, int);
void accept_connexion(fd_set *, server_t *);
void receive_message(zappy_t *, server_t *, fd_set *);
void manage_player(zappy_t *, client_t *, char **);
void player_to_team(zappy_t *, client_t *, char *);
bool is_valid_team_name(zappy_t *, char *);
int get_unsued_player(zappy_t *, char *);
void assign_command(zappy_t *, client_t *, int, char *);
void assign_one_command(zappy_t *, client_t *, char *);
void handle_first_command(zappy_t *, client_t *, char **);
void recup_args(char ***, char *);
bool verify_empty(char *);
bool is_empty(int, client_t *);
void free_array(char ***);
void add_info_to_gui(zappy_t *, char *);
inv_t get_inventory(char *);
void generate_ressources_time(zappy_t *);
size_t count_args(char **);
bool execute_function(zappy_t *, player_t *);
void execute(zappy_t *, player_t *);
void player_eat(zappy_t *, player_t *);
void execute_command(zappy_t *);
void disconnect_player(zappy_t *, client_t *);
void disconnect(zappy_t *, server_t *);
void gui_command(client_t *, char **);
void player_command(client_t *, char **);
void manage_command(client_t *, char **);
void add_new_command(player_t *, command_t *, char **);
void add_command_priority(player_t *, command_t *, char **);
void remove_command(player_t *);
void print_message(int, char *);
void write_buffer(client_t *);
void write_client(server_t *, fd_set *);
void handle_first_command(zappy_t *, client_t *, char **);
void assign_one_command(zappy_t *, client_t *, char *);
void assign_command(zappy_t *, client_t *, int, char *);
void bct(zappy_t *, player_t *, char **);
void mct(zappy_t *, player_t *, char **);
void msz(zappy_t *, player_t *, char **);
void pin(zappy_t *, player_t *, char **);
void plv(zappy_t *, player_t *, char **);
void ppo(zappy_t *, player_t *, char **);
void sgt(zappy_t *, player_t *, char **);
void tna(zappy_t *, player_t *, char **);
void verify_limit(zappy_t *, player_t *);
void change_direction(player_t *, mouvement_t);
void first_broadcast(zappy_t *, player_t *, char **);
void broadcast(zappy_t *, player_t *, char **);
void first_forward(zappy_t *, player_t *, char **);
void forward(zappy_t *, player_t *, char **);
void first_inventory(zappy_t *, player_t *, char **);
void inventory(zappy_t *, player_t *, char **);
void first_left(zappy_t *, player_t *, char **);
void left(zappy_t *, player_t *, char **);
void first_look(zappy_t *, player_t *, char **);
void look(zappy_t *, player_t *, char **);
void first_right(zappy_t *, player_t *, char **);
void right(zappy_t *, player_t *, char **);
void first_connect_nbr(zappy_t *, player_t *, char **);
void connect_nbr(zappy_t *, player_t *, char **);
void first_fork(zappy_t *, player_t *, char **);
void forke(zappy_t *, player_t *, char **);
void hatching(zappy_t *, player_t *, char **);
void first_eject(zappy_t *, player_t *, char **);
void eject(zappy_t *, player_t *, char **);
bool remain_inv(inventory_t, inv_t, int);
void collect_inv(inventory_t *, inv_t, int);
void drop_inv(inventory_t *, inv_t, int);
void update_inv(zappy_t *, player_t *, inventory_t);
void use_inv_for_incantation(zappy_t *, inventory_t *, int);
void first_take(zappy_t *, player_t *, char **);
void take(zappy_t *, player_t *, char **);
void first_set(zappy_t *, player_t *, char **);
void set(zappy_t *, player_t *, char **);
int player_in_tile(zappy_t *, position_t, int);
void first_incantation(zappy_t *, player_t *, char **);
void incantation(zappy_t *, player_t *, char **);
void freeze_incantation(zappy_t *, player_t *, char **);
void player_death(zappy_t *, player_t *, char **);
int abs(int);
void add_message(char *, char *);
void look_left(zappy_t *, player_t *);
void look_right(zappy_t *, player_t *);
void look_down(zappy_t *, player_t *);
void look_up(zappy_t *, player_t *);
void up_sep(player_t *, look_t, int, int);
void down_sep(player_t *, look_t, int, int);
void right_sep(player_t *, look_t, int, int);
void left_sep(player_t *, look_t, int, int);
int player_on_tile(zappy_t *, position_t);
void tile_content(player_t *, zappy_t *, int, int);
void correct_posi(int *, int *, int);
void incantation_success(zappy_t *, player_t *);
void incantation_fail(zappy_t *, player_t *);
int player_on_tile(zappy_t *, position_t);
bool can_incantate(zappy_t *, player_t *);
