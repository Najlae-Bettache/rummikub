/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Structure de gestion de la map
*/

#pragma once

#include "./header.h"
#include "./inventory.h"

typedef struct zappy_s zappy_t;
typedef struct inventory_s inventory_t;
typedef struct player_s player_t;
typedef struct position_s position_t;
typedef struct server_s server_t;
typedef struct client_s client_t;
typedef struct command_s command_t;
typedef struct look_s look_t;
typedef enum inv_s inv_t;
typedef enum mouvement_s mouvement_t;
typedef enum direction_s direction_t;
typedef enum statut_s statut_t;

typedef struct map_s {
    int width;
    int height;
    inventory_t **tiles;
    //player_t **players;
} map_t;
