/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Structure de gestion de zappy
*/

#pragma once

#include "./network.h"
#include "./player.h"
#include "./map.h"
#include "./command.h"

extern bool quit;

typedef struct zappy_s zappy_t;
typedef struct inventory_s inventory_t;
typedef struct player_s player_t;
typedef struct position_s position_t;
typedef struct server_s server_t;
typedef struct client_s client_t;
typedef struct command_s command_t;
typedef struct look_s look_t;
typedef enum inv_s inv_t;
typedef enum mouvement_s mouvement_t;
typedef enum direction_s direction_t;
typedef enum statut_s statut_t;

typedef struct zappy_s {
    int player_id;
    int freq;
    int nb_teams;
    char **teams;
    map_t map;
    SLIST_HEAD(player_list, player_s) head;
    inventory_t inventory;
    long int gen_time;
} zappy_t;
