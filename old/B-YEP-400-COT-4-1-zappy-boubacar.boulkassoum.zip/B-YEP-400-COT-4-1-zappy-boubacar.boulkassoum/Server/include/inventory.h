/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Structure de gestion de l'inventaire
*/

#pragma once
#include "./header.h"

typedef struct zappy_s zappy_t;
typedef struct inventory_s inventory_t;
typedef struct player_s player_t;
typedef struct position_s position_t;
typedef struct server_s server_t;
typedef struct client_s client_t;
typedef struct command_s command_t;
typedef struct look_s look_t;
typedef enum inv_s inv_t;
typedef enum mouvement_s mouvement_t;
typedef enum direction_s direction_t;
typedef enum statut_s statut_t;

typedef enum inv_s {
    FOOD,
    LINEMATE,
    DERAUMERE,
    SIBUR,
    MENDIANE,
    PHIRAS,
    THYSTAME,
    NONE
} inv_t;

typedef struct {
    const char *elem;
    double value;
} density_t;

static const density_t densite[8] = {
    {"FOOD", 0.5},
    {"LINEMATE", 0.3},
    {"DERAUMERE", 0.15},
    {"SIBUR", 0.1},
    {"MENDIANE", 0.1},
    {"PHIRAS", 0.08},
    {"THYSTAME", 0.05},
    {"NONE", -0.9}
};

static const int player_required[] = {1, 2, 2, 4, 4, 6, 6};
static const int linemate_required[] = {1, 1, 2, 1, 1, 1, 2};
static const int deraumere_required[] = {0, 1, 0, 1, 2, 2, 2};
static const int sibur_required[] = {0, 1, 1, 2, 1, 3, 2};
static const int mendiane_required[] = {0, 0, 0, 0, 3, 0, 2};
static const int phiras_required[] = {0, 0, 2, 1, 0, 1, 2};
static const int thystame_required[] = {0, 0, 0, 0, 0, 0, 1};

typedef struct inventory_s {
    int linemate;
    int deraumere;
    int sibur;
    int mendiane;
    int phiras;
    int thystame;
    int food;
} inventory_t;
