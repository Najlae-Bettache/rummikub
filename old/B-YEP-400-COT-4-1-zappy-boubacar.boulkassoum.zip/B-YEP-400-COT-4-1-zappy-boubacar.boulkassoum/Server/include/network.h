/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Structure de gestion des inventaires
*/

#pragma once

#include "./header.h"
#include "./player.h"

typedef struct zappy_s zappy_t;
typedef struct inventory_s inventory_t;
typedef struct player_s player_t;
typedef struct position_s position_t;
typedef struct server_s server_t;
typedef struct client_s client_t;
typedef struct command_s command_t;
typedef struct look_s look_t;
typedef enum inv_s inv_t;
typedef enum mouvement_s mouvement_t;
typedef enum direction_s direction_t;
typedef enum statut_s statut_t;

typedef struct client_s {
    struct sockaddr_in addr;
    int fd;
    bool disconnected;
    char write_buffer[8];
    char read_buffer[4096];
    player_t *player;
    SLIST_ENTRY(client_s) next;
} client_t;

typedef struct server_s {
    int port;
    int sockfd;
    struct sockaddr_in addr_serv;
    socklen_t size;
    client_t *server_client;
    SLIST_HEAD(client_list, client_s) head;
} server_t;
