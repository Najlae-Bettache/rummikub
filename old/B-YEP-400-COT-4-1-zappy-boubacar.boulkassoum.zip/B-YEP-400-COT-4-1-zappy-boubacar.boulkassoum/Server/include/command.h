/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Structure de gestion des commandes
*/

#pragma once
#include "./header.h"

typedef struct zappy_s zappy_t;
typedef struct inventory_s inventory_t;
typedef struct player_s player_t;
typedef struct position_s position_t;
typedef struct server_s server_t;
typedef struct client_s client_t;
typedef struct command_s command_t;
typedef struct look_s look_t;
typedef enum inv_s inv_t;
typedef enum mouvement_s mouvement_t;
typedef enum direction_s direction_t;
typedef enum statut_s statut_t;

typedef struct look_s {
    int i;
    int j;
    int k;
    int l;
} look_t;

typedef struct command_s {
    char *cmd;
    void (*function)(zappy_t *, player_t *, char **);
    void (*second_function)(zappy_t *, player_t *, char **);
    char **args;
    int exec_time;
} command_t;

static command_t PLAYER_COMMANDS[] = {
    {"Forward", first_forward, forward, NULL, 7},
    {"Right", first_right, right, NULL, 7},
    {"Left", first_left, left, NULL, 7},
    {"Look", first_look, look, NULL, 7},
    {"Inventory", first_inventory, inventory, NULL, 1},
    {"Broadcast", first_broadcast, broadcast, NULL, 7},
    {"Connect_nbr", first_connect_nbr, connect_nbr, NULL, 0},
    {"Fork", first_fork, forke, NULL, 42},
    {"Closegg", NULL, hatching, NULL, 600},
    {"Eject", first_eject, eject, NULL, 7},
    {"Take", first_take, take, NULL, 7},
    {"Set", first_set, set, NULL, 7},
    {"Incantation", first_incantation, incantation, NULL, 150},
    {"Freeze", NULL, freeze_incantation, NULL, 150},
    {NULL, NULL, NULL, NULL, 0}
};

static command_t GUI_COMMANDS[] = {
    {"msz", msz, NULL, NULL, 0},
    {"bct", bct, NULL, NULL, 0},
    {"mct", mct, NULL, NULL, 0},
    {"tna", tna, NULL, NULL, 0},
    {"ppo", ppo, NULL, NULL, 0},
    {"plv", plv, NULL, NULL, 0},
    {"pin", pin, NULL, NULL, 0},
    {"sgt", sgt, NULL, NULL, 0},
    {NULL, NULL, NULL, NULL, 0}
};
