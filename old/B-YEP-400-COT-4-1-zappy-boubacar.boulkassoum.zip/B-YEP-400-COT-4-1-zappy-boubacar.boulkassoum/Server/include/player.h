/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Structure de représentation des joueurs
*/

#pragma once

#include "./header.h"
#include "./inventory.h"

typedef struct zappy_s zappy_t;
typedef struct inventory_s inventory_t;
typedef struct player_s player_t;
typedef struct position_s position_t;
typedef struct server_s server_t;
typedef struct client_s client_t;
typedef struct command_s command_t;
typedef struct look_s look_t;
typedef enum inv_s inv_t;
typedef enum mouvement_s mouvement_t;
typedef enum direction_s direction_t;
typedef enum statut_s statut_t;

typedef struct position_s {
    int x;
    int y;
} position_t;

typedef enum direction_s {
    NOWHERE,
    UP_CENTER,
    UP_LEFT,
    CENTER_LEFT,
    DOWN_LEFT,
    DOWN_CENTER,
    DOWN_RIGHT,
    CENTER_RIGHT,
    UP_RIGHT
} direction_t;

typedef enum mouvement_s {
    UP,
    RIGHT,
    DOWN,
    LEFT
} mouvement_t;

typedef enum statut_s {
    INEXISTANT,
    OEUF,
    VIVANT,
    MORT
} statut_t;

typedef struct player_s {
    int id;
    int level;
    char *team_name;
    long int eat_time;
    long int start;
    command_t *command[11];
    statut_t statut;
    inventory_t inventory;
    position_t position;
    mouvement_t mouv;
    char message[40096];
    SLIST_ENTRY(player_s) next;
} player_t;
