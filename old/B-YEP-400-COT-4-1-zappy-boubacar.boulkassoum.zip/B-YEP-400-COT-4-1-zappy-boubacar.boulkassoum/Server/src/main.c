/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Main du programme
*/

#include "../include/network.h"
#include "../include/zappy.h"

//zappy_server -p port -x width -y height -n name1 name2 ... -c clientsNb -f freq
bool quit = false;

void signal_handler(int sig)
{
    if (sig == SIGINT) {
        printf("\nServer close\n");
        quit = true;
    }
}

int main(int ac, char **av)
{
    zappy_t zappy;
    server_t server = {.addr_serv = {0}};
    time_t tim;

    srand((unsigned)time(&tim));
    if (ac < 2)
        exit(84);
    signal(SIGINT, signal_handler);
    initialise_utils(ac, av, &zappy);
    initialise_connexion(ac, av, &server);
    start_zappy(&zappy, &server);
    return 0;
}
