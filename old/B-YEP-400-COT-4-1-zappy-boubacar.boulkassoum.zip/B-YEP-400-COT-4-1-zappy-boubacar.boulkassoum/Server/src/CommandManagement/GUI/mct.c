/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Command mct
*/

#include "../../../include/zappy.h"

void mct(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];
    char strr[400096];

    for (int i = 0; i != zappy->map.height; i++) {
        for (int j = 0; j != zappy->map.width; j++) {
            sprintf(str, "bct %d %d %d %d %d %d %d %d %d \n", j, i,
            zappy->map.tiles[i][j].food,
            zappy->map.tiles[i][j].linemate,
            zappy->map.tiles[i][j].deraumere,
            zappy->map.tiles[i][j].sibur,
            zappy->map.tiles[i][j].mendiane,
            zappy->map.tiles[i][j].phiras,
            zappy->map.tiles[i][j].thystame);
            memmove(strr + strlen(strr), str, strlen(str) + 1);
            memset(str, 0, strlen(str));
        }
    }
    add_info_to_gui(zappy, strr);
}
