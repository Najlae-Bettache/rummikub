/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande pin
*/

#include "../../../include/zappy.h"

void pin(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];
    int n = atoi(args[1]);
    player_t *tmp = malloc(sizeof(player_t));

    SLIST_FOREACH(tmp, &zappy->head, next) {
        if (tmp->id == n) {
            sprintf(str, "pin %d %d %d %d %d %d %d %d %d %d\n", n,
            tmp->position.x, tmp->position.y,
            tmp->inventory.food, tmp->inventory.linemate,
            tmp->inventory.deraumere, tmp->inventory.sibur,
            tmp->inventory.mendiane,
            tmp->inventory.phiras,
            tmp->inventory.thystame);
            add_info_to_gui(zappy, str);
            break;
        }
    }
}
