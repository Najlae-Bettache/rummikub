/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande sgt
*/

#include "../../../include/zappy.h"

void sgt(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];

    sprintf(str, "sgt %d\n", zappy->freq);
    add_info_to_gui(zappy, str);
}
