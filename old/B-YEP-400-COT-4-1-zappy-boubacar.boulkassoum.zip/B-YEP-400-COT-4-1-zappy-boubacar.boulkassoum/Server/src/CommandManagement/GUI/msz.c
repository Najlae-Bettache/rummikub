/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande msz
*/

#include "../../../include/zappy.h"

void msz(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];

    sprintf(str, "msz %d %d\n", zappy->map.width, zappy->map.height);
    add_info_to_gui(zappy, str);
}
