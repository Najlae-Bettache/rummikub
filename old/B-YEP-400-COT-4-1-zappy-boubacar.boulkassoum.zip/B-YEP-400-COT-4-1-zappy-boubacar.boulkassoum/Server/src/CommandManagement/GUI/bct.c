/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande bct
*/

#include "../../../include/zappy.h"

void bct(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];
    int x = atoi(args[1]);
    int y = atoi(args[2]);

    sprintf(str, "bct %d %d %d %d %d %d %d %d %d\n", x, y,
    zappy->map.tiles[y][x].food,
    zappy->map.tiles[y][x].linemate,
    zappy->map.tiles[y][x].deraumere,
    zappy->map.tiles[y][x].sibur,
    zappy->map.tiles[y][x].mendiane,
    zappy->map.tiles[y][x].phiras,
    zappy->map.tiles[y][x].thystame);
    add_info_to_gui(zappy, str);
}
