/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande tna
*/

#include "../../../include/zappy.h"

void tna(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];

    for (int i = 0; zappy->teams[i]; i++) {
        sprintf(str, "tna %s\n", zappy->teams[i]);
        add_info_to_gui(zappy, str);
        memset(str, 0, strlen(str));
    }
}
