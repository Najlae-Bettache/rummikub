/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Fonction d'ajout de nouvelles commandes dans la liste des commandes du joueu
*/

#include "../../include/zappy.h"

void initialise_args(player_t *player, int i, char **args)
{
    int j = 0;
    player->command[0]->args = malloc(sizeof(char *) * (count_args(args) + 1));
    if (args) {
        for (j = 0; args[j]; j++)
            player->command[i]->args[j] = strdup(args[j]);
    }
    player->command[i]->args[j] = NULL;
}

void add_command_priority(player_t *player, command_t *new, char **args)
{
    int i = 0;

    for (i = 0; player->command[i]; i++);
    for (; i != 0; i--) {
        if (i == 9) {
            free(player->command[i]);
            player->command[i] = NULL;
        }
        player->command[i] = player->command[i - 1];
    }
    if (!player->command[0]) {
        player->command[0] = malloc(sizeof(*player->command[0]));
        player->command[0]->cmd = new->cmd;
        player->command[0]->function = new->function;
        player->command[0]->second_function = new->second_function;
        player->command[0]->exec_time = new->exec_time;
    }
    initialise_args(player, i, args);
}

void add_new_command(player_t *player, command_t *new, char **args)
{
    int i = 0;
    int j = 0;
    int nb_args = count_args(args);

    for (i = 0; player->command[i]; i++);
    if (i >= 10)
        return;
    if (!player->command[i]) {
        player->command[i] = malloc(sizeof(*player->command[i]));
        player->command[i]->cmd = new->cmd;
        player->command[i]->function = new->function;
        player->command[i]->second_function = new->second_function;
        player->command[i]->exec_time = new->exec_time;
    }
    player->command[i]->args = malloc(sizeof(char *) * (nb_args + 1));
    for (j = 0; args[j]; j++)
        player->command[i]->args[j] = strdup(args[j]);
    player->command[i]->args[j] = NULL;
}

void remove_command(player_t *player)
{
    if (!player->command[0])
        return;
    if (player->command[0]->args)
        free_array(&(player->command[0]->args));
    free(player->command[0]);
    player->command[0] = NULL;
    for (int i = 0; player->command[i]; i++) {
        if (i == 9) {
            player->command[i] = NULL;
            break;
        }
        player->command[i] = player->command[i + 1];
    }
}
