/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Fonction de répartition des commandes selon le type de joueurs
*/

#include "../../include/zappy.h"

void gui_command(client_t *client, char **args)
{
    for (size_t i = 0; GUI_COMMANDS[i].cmd; i++) {
        if (strcmp(GUI_COMMANDS[i].cmd, args[0]) == 0) {
            add_new_command(client->player, &GUI_COMMANDS[i], args);
            break;
        }
    }
}

void player_command(client_t *client, char **args)
{
    for (size_t i = 0; PLAYER_COMMANDS[i].cmd; i++) {
        if (strcmp(PLAYER_COMMANDS[i].cmd, args[0]) == 0) {
            add_new_command(client->player, &PLAYER_COMMANDS[i], args);
            break;
        }
    }
}

void manage_command(client_t *client, char **args)
{
    if (strcmp(client->player->team_name, "GUI") == 0)
        gui_command(client, args);
    else
        player_command(client, args);
}
