/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande Broadcast
*/

#include "../../../include/zappy.h"

void first_broadcast(zappy_t *zappy, player_t *player, char **args)
{
    char str[1128];

    player->start = clock();
    if (!args || !args[1])
        return;
    sprintf(str, "pbc %d %s\n", player->id, args[1]);
    add_info_to_gui(zappy, str);
}

int path_min(int x1, int x2, int full_length)
{
    int res = x2 - x1;

    if (abs(res) > full_length / 2 && res > 0)
        res = res - full_length;
    if (abs(res) > full_length / 2 && res < 0)
        res = full_length + res;
    return res;
}

direction_t direction(int x, int y, position_t reciever, position_t sender)
{
    if (reciever.x == sender.x && reciever.y == sender.y)
        return NOWHERE;
    if (y > 0 && sender.x == reciever.x)
        return DOWN_CENTER;
    if (y < 0 && sender.x == reciever.x)
        return UP_CENTER;
    if (sender.y == reciever.y && x > 0)
        return CENTER_LEFT;
    if (sender.y == reciever.y && x < 0)
        return CENTER_RIGHT;
    if (y > 0 && x > 0)
        return DOWN_LEFT;
    if (y > 0 && x < 0)
        return DOWN_RIGHT;
    if (y < 0 && x > 0)
        return UP_LEFT;
    if (y < 0 && x < 0)
        return UP_RIGHT;
    return NOWHERE;
}

int sound_dire(zappy_t *zappy, mouvement_t mouv, position_t reciever,
    position_t sender)
{
    direction_t res;
    int x = path_min(sender.x, reciever.x, zappy->map.width);
    int y = path_min(sender.y, reciever.y, zappy->map.height);

    res = direction(x, y, reciever, sender);
    if (res == NOWHERE)
        return res;
    if (mouv == RIGHT)
        res += 2;
    if (mouv == DOWN)
        res += 4;
    if (mouv == LEFT)
        res += 6;
    if (res > 8)
        res -= 8;
    return res;
}

void broadcast(zappy_t *zappy, player_t *player, char **args)
{
    char str[8046];
    char ok[8] = "ok\n";
    player_t *tmp = malloc(sizeof(player_t));

    if (args == NULL || args[1] == NULL)
        return;
    SLIST_FOREACH(tmp, &zappy->head, next) {
        if (tmp->id != player->id && tmp->statut == VIVANT) {
            sprintf(str, "message %d, %s\n", sound_dire(zappy, tmp->mouv,
    tmp->position, player->position), args[1]);
            memmove(tmp->message + strlen(tmp->message), str, strlen(str) + 1);
        }
    }
    memmove(player->message + strlen(player->message), ok, strlen(ok) + 1);
}
