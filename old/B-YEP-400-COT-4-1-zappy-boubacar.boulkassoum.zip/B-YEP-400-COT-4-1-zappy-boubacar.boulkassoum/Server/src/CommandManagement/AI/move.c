/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Mouvement du joueur sur la map
*/

#include "../../../include/zappy.h"

void change_direction(player_t *player, mouvement_t mouv)
{
    if (mouv == UP)
        player->position.y++;
    if (mouv == DOWN)
        player->position.y--;
    if (mouv == RIGHT)
        player->position.x++;
    if (mouv == LEFT)
        player->position.x--;
}

void verify_limit(zappy_t *zappy, player_t *player)
{
    if (player->position.x < 0)
        player->position.x = zappy->map.width - 1;
    if (player->position.x == zappy->map.width)
        player->position.x = 0;
    if (player->position.y < 0)
        player->position.y = zappy->map.height - 1;
    if (player->position.y == zappy->map.height)
        player->position.y = 0;
}
