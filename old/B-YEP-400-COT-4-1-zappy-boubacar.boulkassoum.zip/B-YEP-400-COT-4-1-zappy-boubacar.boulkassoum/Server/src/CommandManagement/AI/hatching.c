/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande d'éclosion de l'œuf
*/

#include "../../../include/zappy.h"

void hatching(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];

    player->statut = INEXISTANT;
    player->eat_time = clock();
    sprintf(str, "ebo %d\n", player->id);
    add_info_to_gui(zappy, str);
}
