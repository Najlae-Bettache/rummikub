/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande Inventory
*/

#include "../../../include/zappy.h"

void first_inventory(zappy_t *zappy, player_t *player, char **args)
{
    player->start = clock();
}

void inventory(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];

    sprintf(str, "[linemate %d, deraumere %d, sibur %d, mendiane %d, phiras %d"
    ", thystame %d, food %d]\n",
    player->inventory.linemate,
    player->inventory.deraumere,
    player->inventory.sibur,
    player->inventory.mendiane,
    player->inventory.phiras,
    player->inventory.thystame,
    player->inventory.food);
    memmove(player->message + strlen(player->message), str, strlen(str) + 1);
}
