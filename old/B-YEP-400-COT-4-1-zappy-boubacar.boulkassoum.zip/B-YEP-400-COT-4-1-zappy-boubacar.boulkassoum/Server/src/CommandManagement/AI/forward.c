/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande Forward
*/

#include "../../../include/zappy.h"

void first_forward(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];
    player_t tmp = *player;

    player->start = clock();
    forward(zappy, &tmp, args);
    sprintf(str, "ppo %d %d %d %d\n", tmp.id,
    tmp.position.x, tmp.position.y,
    tmp.mouv + 1);
    add_info_to_gui(zappy, str);
}

void forward(zappy_t *zappy, player_t *player, char **args)
{
    char str[128] = "ok\n";

    change_direction(player, player->mouv);
    verify_limit(zappy, player);
    memmove(player->message + strlen(player->message), str, strlen(str) + 1);
}
