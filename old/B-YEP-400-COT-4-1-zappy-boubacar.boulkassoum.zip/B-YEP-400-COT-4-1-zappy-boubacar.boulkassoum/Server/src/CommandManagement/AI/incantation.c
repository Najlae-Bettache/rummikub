/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande Incantation
*/

#include "../../../include/zappy.h"

void start_all_player_incantation(zappy_t *zappy, player_t *pl)
{
    char str[128];
    char ele[128] = "Elevation underway\n";
    player_t *tmp = malloc(sizeof(player_t));

    SLIST_FOREACH(tmp, &zappy->head, next) {
        if (tmp->id != pl->id && tmp->level == pl->level &&
    tmp->position.x == pl->position.x && tmp->position.y == pl->position.y)
            if (tmp->statut == VIVANT && tmp->start == -1) {
                memmove(pl->message + strlen(pl->message), ele,
    strlen(ele) + 1);
                add_command_priority(tmp, &PLAYER_COMMANDS[13], NULL);
                tmp->start = clock();
                sprintf(str, " %d", tmp->id);
                add_info_to_gui(zappy, str);
            }
    }
    add_info_to_gui(zappy, "\n");
}

void first_incantation(zappy_t *zappy, player_t *player, char **args)
{
    char ele[128] = "Elevation underway\n";
    char ko[8] = "ko\n";
    char str[128];

    if (can_incantate(zappy, player)) {
        player->start = clock();
        memmove(player->message + strlen(player->message), ele,
    strlen(ele) + 1);
        sprintf(str, "pic %d %d %d %d", player->position.x, player->position.y,
    player->level, player->id);
        add_info_to_gui(zappy, str);
        start_all_player_incantation(zappy, player);
    } else {
        memmove(player->message + strlen(player->message), ko, strlen(ko) + 1);
        player->start = -2;
    }
}

void incantation_success(zappy_t *zappy, player_t *player)
{
    char str[128];
    char strr[128];
    player_t *tmp = malloc(sizeof(player_t));
    int level = player->level;

    SLIST_FOREACH(tmp, &zappy->head, next) {
        if (tmp->position.x == player->position.x &&
            tmp->position.y == player->position.y &&
            tmp->level == level &&
            tmp->statut == VIVANT) {
                tmp->level++;
                sprintf(str, "plv %d %d\n", tmp->id, tmp->level);
                sprintf(strr, "Current level: %d\n", tmp->level);
                memmove(tmp->message + strlen(tmp->message), strr,
    strlen(strr) + 1);
                add_info_to_gui(zappy, str);
        }
        memset(str, 0, strlen(str));
        memset(strr, 0, strlen(strr));
    }
}

void incantation_fail(zappy_t *zappy, player_t *player)
{
    char str[128];
    char ko[8] = "ko\n";
    player_t *tmp = malloc(sizeof(player_t));

    SLIST_FOREACH(tmp, &zappy->head, next) {
        if (tmp->position.x == player->position.x &&
            tmp->position.y == player->position.y &&
            tmp->level == player->level &&
            tmp->statut == VIVANT) {
                sprintf(str, "pie %d %d %d\n", tmp->position.x,
        tmp->position.y, 0);
                memmove(player->message + strlen(player->message), ko,
        strlen(ko) + 1);
                add_info_to_gui(zappy, str);
        }
    }
}

void incantation(zappy_t *zappy, player_t *pl, char **args)
{
    char str[128];
    char strr[128];
    inventory_t *inv = &zappy->map.tiles[pl->position.y][pl->position.x];
    int x = pl->position.x;
    int y = pl->position.y;

    if (can_incantate(zappy, pl)) {
        use_inv_for_incantation(zappy, inv, pl->level);
        sprintf(strr, "bct %d %d %d %d %d %d %d %d %d\n", x, y,
    zappy->map.tiles[y][x].food, zappy->map.tiles[y][x].linemate,
    zappy->map.tiles[y][x].deraumere, zappy->map.tiles[y][x].sibur,
    zappy->map.tiles[y][x].mendiane, zappy->map.tiles[y][x].phiras,
    zappy->map.tiles[y][x].thystame);
        add_info_to_gui(zappy, strr);
        incantation_success(zappy, pl);
        sprintf(str, "pie %d %d %d\n", pl->position.x, pl->position.y,
    pl->level);
        add_info_to_gui(zappy, str);
    } else
        incantation_fail(zappy, pl);
}
