/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande Eject
*/

#include "../../../include/zappy.h"

mouvement_t opposite(mouvement_t eject_dir)
{
    if (eject_dir == UP)
        return DOWN;
    if (eject_dir == DOWN)
        return UP;
    if (eject_dir == RIGHT)
        return LEFT;
    if (eject_dir == LEFT)
        return RIGHT;
    return UP;
}

void first_eject(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];
    char strr[128];
    player_t *temp = malloc(sizeof(player_t));
    player_t *tmp = malloc(sizeof(player_t));

    player->start = clock();
    sprintf(str, "pex %d\n", player->id);
    add_info_to_gui(zappy, str);
    SLIST_FOREACH(tmp, &zappy->head, next) {
        if (tmp->id != player->id &&
        player->position.x == tmp->position.x &&
        player->position.y == tmp->position.y) {
            temp = tmp;
            change_direction(temp, player->mouv);
            verify_limit(zappy, temp);
            sprintf(strr, "eject: %d\n", opposite(player->mouv));
            memmove(player->message + strlen(player->message), strr,
    strlen(strr) + 1);
        }
    }
}

void eject(zappy_t *zappy, player_t *player, char **args)
{
    player_t *tmp = malloc(sizeof(player_t));
    char ok[8] = "ok\n";
    char strr[128];

    SLIST_FOREACH(tmp, &zappy->head, next) {
        if (tmp->id != player->id &&
            player->position.x == tmp->position.x &&
            player->position.y == tmp->position.y) {
                change_direction(tmp, player->mouv);
                verify_limit(zappy, tmp);
                sprintf(strr, "eject: %d\n", opposite(player->mouv));
                memmove(player->message + strlen(player->message), strr,
    strlen(strr) + 1);
        }
    }
    memmove(player->message + strlen(player->message), ok, strlen(ok) + 1);
}
