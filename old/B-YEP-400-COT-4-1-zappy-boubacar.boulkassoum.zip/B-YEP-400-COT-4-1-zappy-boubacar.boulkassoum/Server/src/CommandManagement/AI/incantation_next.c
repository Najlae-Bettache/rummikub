/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Suite des fonction de la commande incantation
*/

#include "../../../include/zappy.h"

void freeze_incantation(zappy_t *zappy, player_t *player, char **args)
{
    return;
}

bool can_incantate(zappy_t *zappy, player_t *player)
{
    inventory_t all = zappy->map.tiles[player->position.y][player->position.x];
    int player_nb = player_required[player->level - 1];
    int linemate_nb = linemate_required[player->level - 1];
    int deraumere_nb = deraumere_required[player->level - 1];
    int sibur_nb = sibur_required[player->level - 1];
    int mendiane_nb = mendiane_required[player->level - 1];
    int phiras_nb = phiras_required[player->level - 1];
    int thystame_nb = thystame_required[player->level - 1];

    if (remain_inv(all, LINEMATE, linemate_nb) &&
    remain_inv(all, DERAUMERE, deraumere_nb) &&
    remain_inv(all, SIBUR, sibur_nb))
        if (remain_inv(all, MENDIANE, mendiane_nb) &&
    remain_inv(all, PHIRAS, phiras_nb) &&
    remain_inv(all, THYSTAME, thystame_nb)) {
            return true;
        } else
            return false;
}
