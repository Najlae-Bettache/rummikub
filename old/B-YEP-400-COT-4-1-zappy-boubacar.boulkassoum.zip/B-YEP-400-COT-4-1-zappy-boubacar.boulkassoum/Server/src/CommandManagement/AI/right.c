/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande Right
*/

#include "../../../include/zappy.h"

void first_right(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];
    player_t tmp = *player;

    player->start = clock();
    right(zappy, &tmp, args);
    sprintf(str, "ppo %d %d %d %d\n", tmp.id,
    tmp.position.x, tmp.position.y,
    tmp.mouv + 1);
    add_info_to_gui(zappy, str);
}

void right(zappy_t *zappy, player_t *player, char **args)
{
    char str[128] = "ok\n";
    bool change_time = false;

    if (player->mouv == UP && !change_time) {
        player->mouv = RIGHT;
        change_time = true;
    }
    if (player->mouv == DOWN && !change_time) {
        player->mouv = LEFT;
        change_time = true;
    }
    if (player->mouv == RIGHT && !change_time) {
        player->mouv = DOWN;
        change_time = true;
    }
    if (player->mouv == LEFT && !change_time)
        player->mouv = UP;
    memmove(player->message + strlen(player->message), str, strlen(str) + 1);
}
