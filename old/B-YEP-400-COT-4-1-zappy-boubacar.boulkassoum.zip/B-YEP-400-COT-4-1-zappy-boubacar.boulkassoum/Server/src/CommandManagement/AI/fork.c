/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande Fork
*/

#include "../../../include/zappy.h"

void first_fork(zappy_t *zappy, player_t *player, char **args)
{
    player->start = clock();
}

void forke(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];
    char ok[8] = "ok\n";
    player_t *egg = malloc(sizeof(player_t));

    new_egg(egg, player->team_name, zappy, player->position);
    memmove(player->message + strlen(player->message), ok, strlen(ok) + 1);
    add_command_priority(egg, &PLAYER_COMMANDS[8], NULL);
    egg->start = clock();
    SLIST_INSERT_HEAD(&zappy->head, egg, next);
    zappy->player_id++;
    sprintf(str, "enw %d %d %d %d\n", egg->id, player->id, egg->position.x,
    egg->position.y);
    add_info_to_gui(zappy, str);
}
