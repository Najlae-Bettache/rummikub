/*
** EPITECH PROJECT, 2024
** B-YEP-400-COT-4-1-zappy-boubacar.boulkassoum
** File description:
** look_dir
*/

#include "../../../include/zappy.h"

int player_on_tile(zappy_t *zappy, position_t xy)
{
    player_t *tmp = malloc(sizeof(player_t));
    int total = 0;

    SLIST_FOREACH(tmp, &zappy->head, next) {
        if (tmp->position.x == xy.x && tmp->position.y == xy.y &&
    tmp->statut == VIVANT)
            total++;
    }
    return total;
}

void look_up(zappy_t *zappy, player_t *player)
{
    look_t position = {1,
    player->position.x,
    player->position.x + 1,
    player->position.y + player->level + 1};

    add_message(player->message, "[");
    for (int i = player->position.y; i != position.l;
    i++, position.i += 2, position.j -= 1) {
        correct_posi(&i, &position.l, zappy->map.height);
        correct_posi(&position.j, NULL, zappy->map.width);
        position.k = position.j + position.i;
        for (int n = position.j; n != position.k; n++) {
            correct_posi(&n, &position.k, zappy->map.width);
            tile_content(player, zappy, n, i);
            up_sep(player, position, i, n);
        }
    }
    add_message(player->message, " ]\n");
}

void look_down(zappy_t *zappy, player_t *player)
{
    look_t position = {1, player->position.x, player->position.x + 1,
    player->position.y - player->level - 1};

    add_message(player->message, "[");
    for (int i = player->position.y; i != position.l; i--,
    position.j += 2, position.j += 1) {
        correct_posi(&i, &position.l, zappy->map.height);
        correct_posi(&position.j, NULL, zappy->map.width);
        position.k = position.j - position.j;
        for (int n = position.j; n != position.k; n--) {
            correct_posi(&n, &position.k, zappy->map.width);
            tile_content(player, zappy, n, i);
            down_sep(player, position, i, n);
        }
    }
    add_message(player->message, " ]\n");
}

void look_right(zappy_t *zappy, player_t *player)
{
    look_t position = {1, player->position.y,
    player->position.x + player->level + 1, player->position.y + 1};

    add_message(player->message, "[");
    for (int i = player->position.x; i != position.k; i++,
    position.i += 2, position.j += 1) {
        correct_posi(&i, &position.k, zappy->map.width);
        correct_posi(&position.j, NULL, zappy->map.height);
        position.l = position.j - position.i;
        for (int n = position.j; n != position.l; n--) {
            correct_posi(&n, &position.l, zappy->map.height);
            tile_content(player, zappy, i, n);
            right_sep(player, position, i, n);
        }
    }
    add_message(player->message, " ]\n");
}

void look_left(zappy_t *zappy, player_t *player)
{
    look_t position = {1, player->position.y,
    player->position.x - player->level - 1, player->position.y + 1};

    add_message(player->message, "[");
    for (int i = player->position.x; i != position.k; i--,
    position.i += 2, position.j -= 1) {
        correct_posi(&i, &position.k, zappy->map.width);
        correct_posi(&position.j, NULL, zappy->map.height);
        position.l = position.j + position.i;
        for (int n = position.j; n != position.l; n++) {
            correct_posi(&n, &position.l, zappy->map.height);
            tile_content(player, zappy, i, n);
            left_sep(player, position, i, n);
        }
    }
    add_message(player->message, " ]\n");
}
