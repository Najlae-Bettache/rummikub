/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Gestion des inventaires
*/

#include "../../../include/zappy.h"

bool remain_inv(inventory_t inventory, inv_t inv, int nb)
{
    if (inv == FOOD && inventory.food < nb)
        return false;
    if (inv == LINEMATE && inventory.linemate < nb)
        return false;
    if (inv == DERAUMERE && inventory.deraumere < nb)
        return false;
    if (inv == SIBUR && inventory.sibur < nb)
        return false;
    if (inv == MENDIANE && inventory.mendiane < nb)
        return false;
    if (inv == PHIRAS && inventory.phiras < nb)
        return false;
    if (inv == THYSTAME && inventory.thystame < nb)
        return false;
    return true;
}

void collect_inv(inventory_t *inventory, inv_t inv, int nb)
{
    if (inv == FOOD)
        inventory->food -= nb;
    if (inv == LINEMATE)
        inventory->linemate -= nb;
    if (inv == DERAUMERE)
        inventory->deraumere -= nb;
    if (inv == SIBUR)
        inventory->sibur -= nb;
    if (inv == MENDIANE)
        inventory->mendiane -= nb;
    if (inv == PHIRAS)
        inventory->phiras -= nb;
    if (inv == THYSTAME)
        inventory->thystame -= nb;
}

void drop_inv(inventory_t *inventory, inv_t inv, int nb)
{
    if (inv == FOOD)
        inventory->food += nb;
    if (inv == LINEMATE)
        inventory->linemate += nb;
    if (inv == DERAUMERE)
        inventory->deraumere += nb;
    if (inv == SIBUR)
        inventory->sibur += nb;
    if (inv == MENDIANE)
        inventory->mendiane += nb;
    if (inv == PHIRAS)
        inventory->phiras += nb;
    if (inv == THYSTAME)
        inventory->thystame += nb;
}

void update_inv(zappy_t *zappy, player_t *pl, inventory_t all)
{
    char str[128];

    sprintf(str, "pin %d %d %d %d %d %d %d %d %d %d\n", pl->id,
    pl->position.x, pl->position.y,
    pl->inventory.food, pl->inventory.linemate,
    pl->inventory.deraumere, pl->inventory.sibur,
    pl->inventory.mendiane,
    pl->inventory.phiras,
    pl->inventory.thystame);
    sprintf(str, "bct %d %d %d %d %d %d %d %d %d\n", pl->position.x,
    pl->position.y, all.food, all.linemate, all.deraumere, all.sibur,
    all.mendiane, all.phiras, all.thystame);
    add_info_to_gui(zappy, str);
}

void use_inv_for_incantation(zappy_t *zappy, inventory_t *inv, int lvl)
{
    collect_inv(inv, LINEMATE, linemate_required[lvl - 1]);
    collect_inv(inv, DERAUMERE, deraumere_required[lvl - 1]);
    collect_inv(inv, SIBUR, sibur_required[lvl - 1]);
    collect_inv(inv, MENDIANE, mendiane_required[lvl - 1]);
    collect_inv(inv, PHIRAS, phiras_required[lvl - 1]);
    collect_inv(inv, THYSTAME, thystame_required[lvl - 1]);
    drop_inv(&zappy->inventory, LINEMATE, linemate_required[lvl - 1]);
    drop_inv(&zappy->inventory, DERAUMERE, deraumere_required[lvl - 1]);
    drop_inv(&zappy->inventory, SIBUR, sibur_required[lvl - 1]);
    drop_inv(&zappy->inventory, MENDIANE, mendiane_required[lvl - 1]);
    drop_inv(&zappy->inventory, PHIRAS, phiras_required[lvl - 1]);
    drop_inv(&zappy->inventory, THYSTAME, thystame_required[lvl - 1]);
}
