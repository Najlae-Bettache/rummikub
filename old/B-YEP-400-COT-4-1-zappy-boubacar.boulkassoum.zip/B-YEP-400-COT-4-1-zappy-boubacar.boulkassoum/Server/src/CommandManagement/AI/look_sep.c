/*
** EPITECH PROJECT, 2024
** B-YEP-400-COT-4-1-zappy-boubacar.boulkassoum
** File description:
** look_sep
*/

#include "../../../include/zappy.h"

void add_message(char *new, char *old)
{
    memmove(new + strlen(new), old, strlen(old) + 1);
}

void up_sep(player_t *player, look_t coords, int i, int n)
{
    if (i + 1 != coords.l || n + 1 != coords.k) {
        add_message(player->message, ",");
    }
}

void down_sep(player_t *player, look_t coords, int i, int n)
{
    if (i - 1 != coords.l || n - 1 != coords.k) {
        add_message(player->message, ",");
    }
}

void left_sep(player_t *player, look_t coords, int i, int n)
{
    if (i - 1 != coords.k || n + 1 != coords.l) {
        add_message(player->message, ",");
    }
}

void right_sep(player_t *player, look_t coords, int i, int n)
{
    if (i + 1 != coords.k || n - 1 != coords.l) {
        add_message(player->message, ",");
    }
}
