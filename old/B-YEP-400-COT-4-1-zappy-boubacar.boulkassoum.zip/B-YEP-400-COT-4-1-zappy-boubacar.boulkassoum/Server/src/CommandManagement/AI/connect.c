/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande connect_nbr
*/

#include "../../../include/zappy.h"

void first_connect_nbr(zappy_t *zappy, player_t *player, char **args)
{
    player->start = clock();
}

void connect_nbr(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];

    sprintf(str, "%d\n", get_unsued_player(zappy, player->team_name));
    memmove(player->message + strlen(player->message), str, strlen(str) + 1);
}
