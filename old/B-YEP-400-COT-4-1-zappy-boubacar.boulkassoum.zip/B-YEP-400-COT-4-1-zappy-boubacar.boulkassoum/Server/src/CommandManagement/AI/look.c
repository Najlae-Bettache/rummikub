/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande Look
*/

#include "../../../include/zappy.h"

void first_look(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];

    player->start = clock();
}

void tile_content_next(player_t *player, zappy_t *zappy, inventory_t inv,
    int *total)
{
    int deraumere = inv.deraumere, sibur = inv.sibur, mendiane = inv.mendiane;
    int phiras = inv.phiras, thystame = inv.thystame, i = 0;

    for (i = 0; i != deraumere; i++)
        add_message(player->message, " deraumere");
    *total += i;
    for (i = 0; i != sibur; i++)
        add_message(player->message, " sibur");
    *total += i;
    for (i = 0; i != mendiane; i++)
        add_message(player->message, " mendiane");
    *total += i;
    for (i = 0; i != phiras; i++)
        add_message(player->message, " phiras");
    *total += i;
    for (i = 0; i != thystame; i++)
        add_message(player->message, " thystame");
    *total += i;
    if (total == 0)
        add_message(player->message, " ");
}

void tile_content(player_t *player, zappy_t *zappy, int x, int y)
{
    position_t xy = {x, y};
    inventory_t inv = zappy->map.tiles[xy.y][xy.x];
    int nb_players = player_on_tile(zappy, xy), food = inv.food;
    int linemate = inv.linemate, deraumere = inv.deraumere;
    int sibur = inv.sibur, mendiane = inv.mendiane;
    int phiras = inv.phiras, thystame = inv.thystame, total = 0;

    for (int i = 0; i != nb_players; i++) {
        add_message(player->message, " player");
        total++;
    }
    for (int i = 0; i != food; i++) {
        add_message(player->message, " food");
        total++;
    }
    for (int i = 0; i != linemate; i++) {
        add_message(player->message, " linemate");
        total++;
    }
    tile_content_next(player, zappy, inv, &total);
}

void correct_posi(int *n, int *goal, int lim)
{
    if (goal == NULL && *n == lim)
        *n = 0;
    else if (goal == NULL && *n < 0)
        *n = lim - 1;
    if (*n == lim) {
        *n = 0;
        *goal -= lim;
    } else if (*n < 0) {
        *n = lim - 1;
        *goal += lim;
    }
}

void look(zappy_t *zappy, player_t *player, char **args)
{
    if (player->mouv == UP)
        look_up(zappy, player);
    if (player->mouv == RIGHT)
        look_right(zappy, player);
    if (player->mouv == DOWN)
        look_down(zappy, player);
    if (player->mouv == LEFT)
        look_left(zappy, player);
}
