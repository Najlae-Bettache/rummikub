/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Commande take
*/

#include "../../../include/zappy.h"

void first_take(zappy_t *zappy, player_t *pl, char **args)
{
    char str[128];
    char ko[8] = "ko\n";
    inventory_t *all = &zappy->map.tiles[pl->position.y][pl->position.x];
    inv_t inv = get_inventory(args[1]);

    if (inv == NONE) {
        memmove(pl->message + strlen(pl->message), ko, strlen(ko) + 1);
        pl->start = -2;
        return;
    }
    if (!remain_inv(*all, inv, 1)) {
        memmove(pl->message + strlen(pl->message), ko, strlen(ko) + 1);
        pl->start = -2;
        return;
    }
    pl->start = clock();
    sprintf(str, "pgt %d %d\n", pl->id, inv);
    add_info_to_gui(zappy, str);
}

void take(zappy_t *zappy, player_t *pl, char **args)
{
    char ok[8] = "ok\n";
    char ko[8] = "ko\n";
    inventory_t *all = &zappy->map.tiles[pl->position.y][pl->position.x];
    inv_t inv = get_inventory(args[1]);

    if (inv == NONE) {
        memmove(pl->message + strlen(pl->message), ko, strlen(ko) + 1);
        return;
    } else if (!remain_inv(*all, inv, 1)) {
        memmove(pl->message + strlen(pl->message), ko, strlen(ko) + 1);
        return;
    }
    collect_inv(all, inv, 1);
    collect_inv(&zappy->inventory, inv, 1);
    drop_inv(&pl->inventory, inv, 1);
    memmove(pl->message + strlen(pl->message), ok, strlen(ok) + 1);
    update_inv(zappy, pl, *all);
}
