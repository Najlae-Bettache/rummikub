/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Fonction d'initialisation des ressources sur la map
*/

#include "../include/zappy.h"

void generate_ressources_time(zappy_t *zappy)
{
    long int start = clock();
    double waiting = (start - zappy->gen_time) / 1000;

    if (waiting >= (20 / zappy->freq)) {
        generate_ressources(zappy);
        zappy->gen_time = clock();
    }
}

void add_ressource_to_map(int x, int y, inventory_t inventory, zappy_t *zappy)
{
    char str[256];

    sprintf(str, "bct %d %d %d %d %d %d %d %d %d\n", x, y, inventory.food,
    inventory.linemate, inventory.deraumere, inventory.sibur, inventory.mendiane,
    inventory.phiras, inventory.thystame);
    add_info_to_gui(zappy, str);
}

void random_ressource(zappy_t *zappy, inv_t elem)
{
    int x = rand() % zappy->map.width;
    int y = rand() % zappy->map.height;

    if (elem == FOOD) {
        zappy->map.tiles[y][x].food++;
        zappy->inventory.food++;
        add_ressource_to_map(x, y, zappy->map.tiles[y][x], zappy);
    }
    if (elem == LINEMATE) {
        zappy->map.tiles[y][x].linemate++;
        zappy->inventory.linemate++;
        add_ressource_to_map(x, y, zappy->map.tiles[y][x], zappy);
    }
    if (elem == DERAUMERE) {
        zappy->map.tiles[y][x].deraumere++;
        zappy->inventory.deraumere++;
        add_ressource_to_map(x, y, zappy->map.tiles[y][x], zappy);
    }
    if (elem == MENDIANE) {
        zappy->map.tiles[y][x].mendiane++;
        zappy->inventory.mendiane++;
        add_ressource_to_map(x, y, zappy->map.tiles[y][x], zappy);
    }
    if (elem == PHIRAS) {
        zappy->map.tiles[y][x].phiras++;
        zappy->inventory.phiras++;
        add_ressource_to_map(x, y, zappy->map.tiles[y][x], zappy);
    }
    if (elem == THYSTAME) {
        zappy->map.tiles[y][x].thystame++;
        zappy->inventory.thystame++;
        add_ressource_to_map(x, y, zappy->map.tiles[y][x], zappy);
    }
    if (elem == SIBUR) {
        zappy->map.tiles[y][x].sibur++;
        zappy->inventory.sibur++;
        add_ressource_to_map(x, y, zappy->map.tiles[y][x], zappy);
    }
}

void generate_ressources(zappy_t *zappy)
{
    int nb_food = zappy->map.width * zappy->map.height * densite[FOOD].value - zappy->inventory.food;
    int nb_linemate = zappy->map.width * zappy->map.height * densite[LINEMATE].value - zappy->inventory.linemate;
    int nb_der = zappy->map.width * zappy->map.height * densite[DERAUMERE].value - zappy->inventory.deraumere;
    int nb_sibur = zappy->map.width * zappy->map.height * densite[SIBUR].value - zappy->inventory.sibur;
    int nb_phiras = zappy->map.width * zappy->map.height * densite[PHIRAS].value - zappy->inventory.phiras;
    int nb_thystame = zappy->map.width * zappy->map.height * densite[THYSTAME].value - zappy->inventory.thystame;
    int nb_mendiane = zappy->map.width * zappy->map.height * densite[MENDIANE].value - zappy->inventory.mendiane;

    for (; nb_food > 0; nb_food--)
        random_ressource(zappy, FOOD);
    for (; nb_linemate > 0; nb_linemate--)
        random_ressource(zappy, LINEMATE);
    for (; nb_der > 0; nb_der--)
        random_ressource(zappy, DERAUMERE);
    for (; nb_sibur > 0; nb_sibur--)
        random_ressource(zappy, SIBUR);
    for (; nb_mendiane > 0; nb_mendiane--)
        random_ressource(zappy, MENDIANE);
    for (; nb_phiras > 0; nb_phiras--)
        random_ressource(zappy, PHIRAS);
    for (; nb_thystame > 0; nb_thystame--)
        random_ressource(zappy, THYSTAME);
}
