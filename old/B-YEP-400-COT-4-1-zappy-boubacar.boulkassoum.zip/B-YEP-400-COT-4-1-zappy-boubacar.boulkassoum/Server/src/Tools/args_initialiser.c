/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Fonctions de récupération des arguments
*/

#include "../../include/zappy.h"

int get_port(int ac, char **av)
{
    int port = 0;
    int i = 0;

    for (; i != ac; i++)
        if (strcmp(av[i], "-p") == 0)
            break;
    if (i == ac)
        exit(84);
    if (i + 1 >= ac || atoi(av[i + 1]) <= 0)
        exit(84);
    port = atoi(av[i + 1]);
    return port;
}

int get_width(int ac, char **av)
{
    int y = 0;
    int i = 0;

    for (; i != ac; i++)
        if (strcmp(av[i], "-x") == 0)
            break;
    if (i == ac)
        exit(84);
    if (i + 1 >= ac || atoi(av[i + 1]) <= 0)
        exit(84);
    y = atoi(av[i + 1]);
    return y;
}

int get_height(int ac, char **av)
{
    int x = 10;
    int i = 0;

    for (; i != ac; i++)
        if (strcmp(av[i], "-y") == 0)
            break;
    if (i == ac)
        exit(84);
    if (i + 1 >= ac || atoi(av[i + 1]) <= 0)
        exit(84);
    x = atoi(av[i + 1]);
    return x;
}

int get_nbclients(int ac, char **av)
{
    int nb = 0;
    int i = 0;

    for (; i != ac; i++)
        if (strcmp(av[i], "-c") == 0)
            break;
    if (i == ac)
        exit(84);
    if (i + 1 >= ac || atoi(av[i + 1]) <= 0)
        exit(84);
    nb = atoi(av[i + 1]);
    return nb;
}

int get_freq(int ac, char **av)
{
    int freq = 0;
    int i = 0;

    for (; i != ac; i++)
        if (strcmp(av[i], "-f") == 0)
            break;
    if (i == ac)
        exit(84);
    if (i + 1 >= ac || atoi(av[i + 1]) <= 0)
        exit(84);
    freq = atoi(av[i + 1]);
    return freq;
}
