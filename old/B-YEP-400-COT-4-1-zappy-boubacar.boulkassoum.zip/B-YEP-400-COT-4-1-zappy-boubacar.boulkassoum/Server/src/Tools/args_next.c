/*
** EPITECH PROJECT, 2024
** B-YEP-400-COT-4-1-zappy-boubacar.boulkassoum
** File description:
** args_next
*/

#include "../../include/zappy.h"

void get_teams(int i, int ac, char **av, zappy_t *zappy)
{
    for (i = i + 1; i < ac && av[i] && av[i][0] != '-'; i++)
    {
        zappy->teams = realloc(zappy->teams, sizeof(char *) * (zappy->nb_teams + 1));
        zappy->teams[zappy->nb_teams] = strdup(av[i]);
        zappy->nb_teams++;
    }
}

size_t count_args(char **args)
{
    size_t i = 0;

    if (args == NULL)
        return i;
    for (; args[i]; i++);
    return i;
}

void random_position(zappy_t *zappy, position_t *position)
{
    position->x = rand() % zappy->map.width;
    position->y = rand() % zappy->map.height;
}

int random_mouvement(void)
{
    mouvement_t direction = RIGHT;
    direction = rand() % 4;
    return direction;
}

void free_array(char ***largs)
{
    char **args = *largs;

    for (size_t i = 0; args[i]; i++) {
        free(args[i]);
    }
    free(*largs);
}
