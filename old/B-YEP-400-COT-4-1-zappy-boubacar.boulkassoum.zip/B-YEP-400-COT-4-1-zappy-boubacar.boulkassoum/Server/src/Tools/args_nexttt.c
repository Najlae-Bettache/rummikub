/*
** EPITECH PROJECT, 2024
** B-YEP-400-COT-4-1-zappy-boubacar.boulkassoum
** File description:
** args_nexttt
*/

#include "../../include/zappy.h"

const char *inventaire[] = {
    "food",
    "linemate",
    "deraumere",
    "sibur",
    "mendiane",
    "phiras",
    "thystame",
    NULL
};

inv_t get_inventory(char *inv)
{
    size_t i = 0;

    if (!inv)
        return NONE;
    for (; inventaire[i]; i++) {
        if (strcmp(inventaire[i], inv) == 0)
            break;
    }
    return i;
}

int player_in_tile(zappy_t *zappy, position_t pos, int lvl)
{
    int i = 0;
    player_t *tmp = malloc(sizeof(player_t));

    SLIST_FOREACH(tmp, &zappy->head, next) {
        if (tmp->position.x == pos.x &&
            tmp->position.y == pos.y &&
            tmp->level == lvl)
            i++;
    }
    return i;
}

int abs(int n)
{
    if (n < 0)
        n *= -1;
    return n;
}
