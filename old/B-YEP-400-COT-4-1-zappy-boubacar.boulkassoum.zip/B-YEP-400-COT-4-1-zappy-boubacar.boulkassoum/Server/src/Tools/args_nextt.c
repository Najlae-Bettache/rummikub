/*
** EPITECH PROJECT, 2024
** B-YEP-400-COT-4-1-zappy-boubacar.boulkassoum
** File description:
** args_nextt
*/

#include "../../include/zappy.h"

bool is_empty(int val, client_t *client)
{
    if (val == 0)
    {
        client->disconnected = true;
        return true;
    }
    return false;
}

bool verify_empty(char *str)
{
    bool empty = true;
    for (size_t i = 0; str[i]; i++)
    {
        if (str[i] != ' ')
        {
            empty = false;
            return empty;
        }
    }
    return empty;
}

void recup_args(char ***args, char *command)
{
    char *separator = " ";
    char *token = strtok(command, separator);
    char **array = malloc(sizeof(char *));

    array[0] = NULL;
    for (int i = 0; token != NULL; i++)
    {
        array = realloc(array, sizeof(char *) * (i + 2));
        if (array == NULL)
            exit(84);
        array[i] = strdup(token);
        array[i + 1] = NULL;
        token = strtok(NULL, separator);
    }
    *args = array;
}

int get_unsued_player(zappy_t *zappy, char *name)
{
    int i = 0;
    player_t *tmp = malloc(sizeof(player_t));

    SLIST_FOREACH(tmp, &zappy->head, next) {
        if (strcmp(tmp->team_name, name) == 0 && tmp->statut == INEXISTANT)
            i++;
    }
    return i;
}

bool is_valid_team_name(zappy_t *zappy, char *team_name)
{
    for (int i = 0; i < zappy->nb_teams; i++) {
        if (strcmp(zappy->teams[i], team_name) == 0)
            return true;
    }
    return false;
}
