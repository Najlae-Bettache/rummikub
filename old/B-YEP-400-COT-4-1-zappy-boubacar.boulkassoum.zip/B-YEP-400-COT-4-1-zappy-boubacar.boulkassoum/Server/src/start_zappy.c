/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Boucle principale de zappy
*/

#include "../include/zappy.h"

void clean_fd_set(fd_set *set, server_t *server)
{
    FD_ZERO(set);
    FD_SET(server->sockfd, set);
}

void start_zappy(zappy_t *zappy, server_t *server)
{
    fd_set readfds;
    fd_set writefds;
    client_t *tmp = malloc(sizeof(client_t));

    while (quit != true) {
        FD_ZERO(&readfds);
        FD_SET(server->sockfd, &readfds);
        SLIST_FOREACH(tmp, &server->head, next) {
            if (tmp->fd > 0) {
                FD_SET(tmp->fd, &readfds);
            }
        }
        select(FD_SETSIZE, &readfds, NULL, NULL, NULL);
        if (quit == true)
            break;
        accept_connexion(&readfds, server);
        receive_message(zappy, server, &readfds);
        execute_command(zappy);
        write_client(server, &readfds);
        disconnect(zappy, server);
    }
}
