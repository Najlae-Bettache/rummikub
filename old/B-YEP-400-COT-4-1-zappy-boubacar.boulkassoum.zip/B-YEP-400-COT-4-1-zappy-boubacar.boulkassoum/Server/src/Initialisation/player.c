/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Initialisation des teams
*/

#include "../../include/zappy.h"

void initialise_teams(int ac, char **av, zappy_t *zappy)
{
    int i = 0;

    for (; i != ac; i++)
        if (strcmp(av[i], "-n") == 0)
            break;
    if (i == ac || i + 1 == ac || av[i + 1] == NULL)
        exit(84);
    zappy->teams = malloc(sizeof(char *) * 2);
    if (zappy->teams == NULL)
        exit(84);
    zappy->nb_teams = 0;
    get_teams(i, ac, av, zappy);
    zappy->teams = realloc(zappy->teams, sizeof(char *) *
    (zappy->nb_teams + 1));
    zappy->teams[zappy->nb_teams] = NULL;
}

void initialise_players(int nbclients, zappy_t *zappy)
{
    player_t *tmp = (player_t *)malloc(sizeof(player_t));

    new_player(tmp, "GUI", zappy);
    tmp->position.x = -1;
    tmp->position.y = -1;
    SLIST_INSERT_HEAD(&zappy->head, tmp, next);
    zappy->player_id++;
    for (int i = 0; zappy->teams[i]; i++) {
        for (int j = 0; j != nbclients; j++, zappy->player_id++) {
            player_t *temp = (player_t *)malloc(sizeof(player_t));
            new_player(temp, zappy->teams[i], zappy);
            SLIST_INSERT_HEAD(&zappy->head, temp, next);
        }
    }
}
