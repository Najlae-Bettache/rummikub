/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Initialisation des inventaires
*/

#include "../../include/zappy.h"

void initialise_inventory(zappy_t *zappy, inventory_t *inventory)
{
    inventory->food = 10;
    inventory->linemate = 0;
    inventory->deraumere = 0;
    inventory->mendiane = 0;
    inventory->sibur = 0;
    inventory->phiras = 0;
    inventory->thystame = 0;
}

void initialise_inventory_map(zappy_t *zappy, inventory_t *inventory)
{
    inventory->food = 0;
    inventory->linemate = 0;
    inventory->deraumere = 0;
    inventory->mendiane = 0;
    inventory->sibur = 0;
    inventory->phiras = 0;
    inventory->thystame = 0;
}
