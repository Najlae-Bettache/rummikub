/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Fonction d'initialisation de la connexion
*/

#include "../../include/zappy.h"

void initialise_them(int sockfd, server_t *server)
{
    server->server_client = NULL;
    server->addr_serv.sin_addr.s_addr = htonl(INADDR_ANY);
    server->addr_serv.sin_family = AF_INET;
    server->addr_serv.sin_port = server->port == 0 ? 0 : htons(server->port);
    server->size = sizeof(server->addr_serv);
    server->sockfd = sockfd;
}

void initialise_connexion(int ac, char **av, server_t *server)
{
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    int opt = 1;

    if (sockfd < 0)
        exit(84);
    SLIST_INIT(&server->head);
    server->port = get_port(ac, av);
    if (server->port < 1 || server->port > 65535) {
        printf("Invalid port, port must be between 1 and 65535\n.");
        exit(84);
    }
    printf("Port: %d\n", server->port);
    initialise_them(sockfd, server);
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) == -1)
        exit(84);
    if (bind(sockfd, (struct sockaddr *)&server->addr_serv, server->size) < 0)
        exit(84);
    if (listen(sockfd, FD_SETSIZE) < 0)
        exit(84);
}
