/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Initialisation de la map de début
*/

#include "../../include/zappy.h"

void initialise_map(zappy_t *zappy)
{
    zappy->map.tiles = malloc(sizeof(inventory_t *) * (zappy->map.height + 1));
    for (int i = 0; i != zappy->map.height; i++) {
        zappy->map.tiles[i] = malloc(sizeof(inventory_t) *
    (zappy->map.width + 1));
        for (int j = 0; j != zappy->map.width; j++) {
            initialise_inventory_map(zappy, &zappy->map.tiles[i][j]);
        }
    }
}
