/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Initialisation d'un nouveau client
*/

#include "../../include/zappy.h"

void initialise_client(client_t *new, struct sockaddr_in addr, int fd)
{
    new->addr = addr;
    new->disconnected = false;
    new->fd = fd;
    new->player = NULL;
    strcpy(new->read_buffer, "");
    strcpy(new->write_buffer, "");
}
