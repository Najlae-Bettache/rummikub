/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Initialisation de la structure zappy avec les arguments passé en ligne de
*/

#include "../../include/zappy.h"

void initialise_utils(int ac, char **av, zappy_t *zappy)
{
    int nbclients = get_nbclients(ac, av);

    SLIST_INIT(&zappy->head);
    zappy->freq = get_freq(ac, av);
    zappy->map.width = get_width(ac, av);
    zappy->map.height = get_height(ac, av);
    initialise_map(zappy);
    initialise_inventory_map(zappy, &zappy->inventory);
    initialise_teams(ac, av, zappy);
    initialise_players(nbclients, zappy);
    generate_ressources(zappy);
}
