/*
** EPITECH PROJECT, 2024
** Epitech YEP
** File description:
** Fonction de kill du joueur
*/

#include "../../include/zappy.h"

void player_death(zappy_t *zappy, player_t *player, char **args)
{
    char str[128];
    char dead[128] = "dead\n";

    player->statut = MORT;
    memmove(player->message + strlen(player->message),
    dead, strlen(dead) + 1);
    sprintf(str, "pdi %d\n", player->id);
    add_info_to_gui(zappy, str);
}
