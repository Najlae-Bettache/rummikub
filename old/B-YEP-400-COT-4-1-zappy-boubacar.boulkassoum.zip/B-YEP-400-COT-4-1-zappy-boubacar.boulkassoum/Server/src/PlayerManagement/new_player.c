/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Création d'un nouveau joueur
*/

#include "../../include/zappy.h"

void new_player(player_t *new, char *name, zappy_t *zappy)
{
    new->team_name = malloc(sizeof(char) * 4096);
    new->start = -1;
    new->eat_time = clock();
    new->team_name = strdup(name);
    new->id = zappy->player_id;
    new->level = 1;
    new->statut = INEXISTANT;
    strcpy(new->message, "");
    for (int i = 0; i < 11; i++) {
        new->command[i] = NULL;
    }
    new->mouv = random_mouvement();
    random_position(zappy, &(new->position));
    initialise_inventory(zappy, &(new->inventory));
}

void new_egg(player_t *new, char *name, zappy_t *zappy, position_t position)
{
    new->id = zappy->player_id;
    new->mouv = random_mouvement();
    new->level = 1;
    new->statut = OEUF;
    new->team_name = malloc(sizeof(char) * 4096);
    new->team_name = strdup(name);
    new->position.x = position.x;
    new->position.y = position.y;
    strcpy(new->message, "");
    initialise_inventory(zappy, &(new->inventory));
}
