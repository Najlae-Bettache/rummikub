/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Fonctions de déconnexion des joueurs
*/

#include "../../include/zappy.h"

void disconnect_player(zappy_t *zappy, client_t *tmp)
{
    char str[128];

    if (tmp->player) {
        tmp->player->statut =
        (tmp->player->statut != MORT ? INEXISTANT : MORT);
        sprintf(str, "pdi %d\n", tmp->player->id);
        add_info_to_gui(zappy, str);
        strcpy(str, "");
    }
}

void disconnect(zappy_t *zappy, server_t *server)
{
    client_t *tmp = malloc(sizeof(client_t));

    SLIST_FOREACH(tmp, &server->head, next) {
        if (tmp->disconnected == true ||
        (tmp->player && tmp->player->statut == MORT)) {
            disconnect_player(zappy, tmp);
            close(tmp->fd);
            SLIST_REMOVE(&server->head, tmp, client_s, next);
        }
    }
}
