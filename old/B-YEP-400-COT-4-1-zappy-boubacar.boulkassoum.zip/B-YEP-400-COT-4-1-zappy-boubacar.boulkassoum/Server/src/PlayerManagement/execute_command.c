/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Fonction d'execution des commandes
*/

#include "../../include/zappy.h"

bool execute_function(zappy_t *zappy, player_t *player)
{
    if (player->start == -1) {
        player->command[0]->function(
            zappy,
            player,
            player->command[0]->args);
        if (player->start == -2 ||
        player->command[0]->second_function == NULL) {
            player->start = -1;
            remove_command(player);
            return false;
        }
    }
    return true;
}

void execute_second_function(zappy_t *zappy, player_t *player)
{
    long int start = clock();
    double waiting = (start - player->start) / 1000;

    if (waiting >= (player->command[0]->exec_time / zappy->freq)) {
        player->command[0]->second_function(
            zappy,
            player,
            player->command[0]->args);
        player->start = -1;
        remove_command(player);
    }
}

void execute(zappy_t *zappy, player_t *player)
{
    if (player->statut != MORT && player->command[0] != NULL) {
        if (!execute_function(zappy, player))
            return;
        execute_second_function(zappy, player);
    }
}

void player_eat(zappy_t *zappy, player_t *player)
{
    long int start = clock();
    double waiting = (start - player->eat_time) / 1000;

    printf("Time remain to eat for player %d is waiting since %f and his food"
    "remaining is %d\n", player->id, waiting, player->inventory.food);
    if (waiting >= (126 / zappy->freq)) {
        player->inventory.food--;
        if (player->inventory.food == 0) {
            player_death(zappy, player, NULL);
        } else
            player->eat_time = clock();
    }
}

void execute_command(zappy_t *zappy)
{
    player_t *tmp = malloc(sizeof(player_t));

    generate_ressources_time(zappy);
    SLIST_FOREACH(tmp, &zappy->head, next) {
        if (tmp->command[0] != NULL)
            execute(zappy, tmp);
        if (strcmp(tmp->team_name, "GUI") != 0 && tmp->statut == VIVANT)
            player_eat(zappy, tmp);
    }
}
