/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Fonction d'ajout des messages dans la queue du GUI
*/

#include "../../include/zappy.h"

void add_info_to_gui(zappy_t *zappy, char *str)
{
    player_t *tmp = malloc(sizeof(player_t));

    SLIST_FOREACH(tmp, &zappy->head, next)
    {
        if (tmp->statut == VIVANT && strcmp(tmp->team_name, "GUI") == 0) {
            memmove(tmp->message + strlen(tmp->message), str, strlen(str) + 1);
        }
    }
}
