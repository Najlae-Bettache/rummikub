/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Fonction d'acception de connexion au serveur
*/

#include "../../include/zappy.h"

void accept_connexion(fd_set *readfds, server_t *server)
{
    struct sockaddr_in addr;
    client_t *new = malloc(sizeof(client_t));
    int fd = -1;

    if (FD_ISSET(server->sockfd, readfds)) {
        fd = accept(server->sockfd, (struct sockaddr *)&addr, &server->size);
        if (fd < 0)
            exit(84);
        dprintf(fd, "Welcome Player\n");
        initialise_client(new, addr, fd);
        SLIST_INSERT_HEAD(&server->head, new, next);
    }
}
