/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Fonction d'ecriture sur le fd du GUI et des player
*/

#include "../../include/zappy.h"

void print_message(int fd, char *buffer)
{
    char buff[40096];
    int i = 0;

    while (buffer[i]) {
        buff[i] = buffer[i];
        if (buff[i] == '\n') {
            buff[i + 1] = '\0';
            printf("MESSAGE: [%s]\n", buff);
            dprintf(fd, "%s", buff);
            memmove(buffer, buffer + i + 1, strlen(buffer + i + 1) + 1);
            i = 0;
        } else
            i++;
    }
}

void write_buffer(client_t *client)
{
    if (strlen(client->write_buffer) != 0) {
        print_message(client->fd, client->write_buffer);
        if (client->write_buffer[0] == '\0') {
            strcpy(client->write_buffer, "");
        }
    }
    if (client->player != NULL
    && strlen(client->player->message) != 0) {
        print_message(client->fd, client->player->message);
        if (client->player->message[0] == '\0') {
            strcpy(client->player->message, "");
        }
    }
}

void write_client(server_t *server, fd_set *writefds)
{
    client_t *tmp = malloc(sizeof(client_t));

    SLIST_FOREACH(tmp, &server->head, next) {
        if (!tmp->disconnected) {
            write_buffer(tmp);
        }
    }
}
