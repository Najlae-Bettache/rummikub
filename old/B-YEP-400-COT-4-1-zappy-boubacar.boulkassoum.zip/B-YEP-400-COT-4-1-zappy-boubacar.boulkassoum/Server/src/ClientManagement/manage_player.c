/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Fonction d'attributoin des joueurs aux différents clients
*/

#include "../../include/zappy.h"

void player_to_team(zappy_t *zappy, client_t *cl, char *name)
{
    char buffer[128];
    char str[128] = "";
    player_t *tmp = malloc(sizeof(player_t));

    SLIST_FOREACH(tmp, &zappy->head, next) {
        if (strcmp(tmp->team_name, name) == 0 && tmp->statut == INEXISTANT) {
            printf("Player N°%d [%s]\n", tmp->id, tmp->team_name);
            tmp->statut = VIVANT;
            cl->player = tmp;
            sprintf(buffer, "%d\n%d %d\n", get_unsued_player(zappy, name),
    zappy->map.width, zappy->map.height);
            memmove(cl->player->message + strlen(cl->player->message),
    buffer, strlen(buffer) + 1);
            sprintf(str, "pnw %d %d %d %d %d %s\n", cl->player->id,
    cl->player->position.x, cl->player->position.y,
    cl->player->mouv + 1, cl->player->level, cl->player->team_name);
            add_info_to_gui(zappy, str);
            break;
        }
    }
}

void manage_player(zappy_t *zappy, client_t *cl, char **args)
{
    char str[128] = "ko\n";

    if (is_valid_team_name(zappy, args[0])) {
        player_to_team(zappy, cl, args[0]);
    } else {
        memmove(cl->write_buffer + strlen(cl->write_buffer),
    str, strlen(str) + 1);
    }
}
