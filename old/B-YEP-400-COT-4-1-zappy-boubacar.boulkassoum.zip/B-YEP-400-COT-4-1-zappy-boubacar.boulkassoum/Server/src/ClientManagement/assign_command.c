/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Fonction d'execution des commandes ou messages
*/

#include "../../include/zappy.h"

void handle_first_command(zappy_t *zappy, client_t *client, char **args)
{
    player_t *tmp = malloc(sizeof(player_t));
    char str[128] = "WELCOME GUI\n";

    if (strcmp(args[0], "GUI") == 0) {
        SLIST_FOREACH(tmp, &zappy->head, next) {
            if (strcmp(tmp->team_name, "GUI") == 0) {
                printf("%s", str);
                client->player = tmp;
                client->player->statut = VIVANT;
            }
        }
        memmove(client->write_buffer + strlen(client->write_buffer),
    str, strlen(str) + 1);
    } else {
        manage_player(zappy, client, args);
    }
}

void assign_one_command(zappy_t *zappy, client_t *client, char *command)
{
    size_t end = 0;
    char **args = NULL;

    for (end = 0; command[end] && command[end] != '\n' &&
    command[end] != '\r'; end++);
    command[end] = '\0';
    if (strlen(command) > 0 && (command[0] == '\r' || command[0] == '\n'))
        return;
    if (verify_empty(command))
        return;
    recup_args(&args, command);
    if (client->player == NULL)
        handle_first_command(zappy, client, args);
    else
        manage_command(client, args);
    free_array(&args);
}

void assign_command(zappy_t *zappy, client_t *client, int val, char *command)
{
    char buff[4096];
    int i = 0;

    if (is_empty(val, client))
        return;
    command[val] = '\0';
    strcat(client->read_buffer, command);
    while (client->read_buffer[i]) {
        buff[i] = client->read_buffer[i];
        if (buff[i] == '\n') {
            buff[i] = '\0';
            assign_one_command(zappy, client, buff);
            strcpy(buff, "");
            memmove(client->read_buffer, client->read_buffer + i + 1,
    strlen(client->read_buffer) + i + 1);
            i = 0;
        } else
            i++;
    }
}
