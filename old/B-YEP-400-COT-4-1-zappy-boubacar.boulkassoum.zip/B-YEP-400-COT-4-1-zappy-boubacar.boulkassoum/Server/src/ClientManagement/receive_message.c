/*
** EPITECH PROJECT, 2024
** Epitech YEP Zappy
** File description:
** Fonction pour recevoir les commandes des différents clients
*/

#include "../../include/zappy.h"

void receive_message(zappy_t *zappy, server_t *server, fd_set *readfds)
{
    char buffer[4096];
    ssize_t val = 0;
    client_t *tmp = malloc(sizeof(client_t));

    SLIST_FOREACH(tmp, &server->head, next) {
        if (FD_ISSET(tmp->fd, readfds)) {
            for (int i = 0; i < 4096; i++)
                buffer[i] = '\0';
            val = read(tmp->fd, &buffer, 4095);
            assign_command(zappy, tmp, val, buffer);
        }
    }
}
