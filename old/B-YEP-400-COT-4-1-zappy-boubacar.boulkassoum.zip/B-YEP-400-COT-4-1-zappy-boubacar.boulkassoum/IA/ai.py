import socket
import time

class ZappyAI:
    def __init__(self, host, port, team_name):
        self.host = host
        self.port = port
        self.team_name = team_name
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.inventory = {}
        self.client_num = None
        self.world_size = (None, None)
        self.current_level = 1
        self.required_players = {2: 1, 3: 2, 4: 4, 5: 4, 6: 6, 7: 6}
        self.test_mode = test_mode

    def connect(self):
        try:
            self.sock.connect((self.host, self.port))
            welcome_message = self.sock.recv(1024).decode().strip()
            print(f"Received: {welcome_message}")

            if welcome_message == "Welcome Player":
                self.sock.sendall(f"{self.team_name}\n".encode())
                time.sleep(0.5)
                self.handle_server_messages()
            else:
                print("Failed to receive Welcome Player message from server")
        except Exception as e:
            print(f"An error occurred: {e}")
            self.close()

    def handle_server_messages(self):
        try:
            response = self.sock.recv(1024).decode().strip()

            if response:
                parts = response.split('\n')
                if len(parts) >= 2:
                    client_num_response = parts[0]
                    world_size_response = parts[1]

                    self.client_num = int(client_num_response)
                    print(f"Client number: {self.client_num}")

                    world_size_parts = world_size_response.split()
                    if len(world_size_parts) == 2:
                        self.world_size = (int(world_size_parts[0]), int(world_size_parts[1]))
                        print(f"World size: {self.world_size}")

                    if len(parts) > 2 and parts[2] == "dead":
                        print("Received 'dead' message, disconnecting")
                        self.close()
                        return
                    
                    self.main_loop()
                else:
                    print("Failed to parse the server response correctly")
            else:
                print("No response received")
                time.sleep(0.5)
        except Exception as e:
            print(f"An error occurred while handling server messages: {e}")
            self.close()

    def send_command(self, command):
        try:
            print(f"Sending command: {command}")
            self.sock.sendall(f"{command}\n".encode())
            time.sleep(0.1)
            response = self.sock.recv(1024).decode()
            print(f"Received response: {response}")
            return response
        except Exception as e:
            print(f"An error occurred while sending command '{command}': {e}")
            self.close()

    def move_forward(self):
        return self.send_command('Forward')

    def turn_right(self):
        return self.send_command('Right')

    def turn_left(self):
        return self.send_command('Left')

    def look_around(self):
        return self.send_command('Look')

    def check_inventory(self):
        return self.send_command('Inventory')

    def broadcast_message(self, message):
        return self.send_command(f'Broadcast {message}')

    def connect_nbr(self):
        return self.send_command('Connect_nbr')

    def fork_player(self):
        return self.send_command('Fork')

    def eject_players(self):
        return self.send_command('Eject')

    def take_object(self, obj):
        return self.send_command(f'Take {obj}')

    def set_object_down(self, obj):
        return self.send_command(f'Set {obj}')

    def start_incantation(self):
        return self.send_command('Incantation')

    def collect_resource(self, resource, vision):
        food_collected = False

        for i, cell in enumerate(vision):
            print(f"Checking cell {i}: {cell}")
            if 'food' in cell:
                if i == 0:
                    print(f"Food found in cell {i}")
                    self.take_object('food')
                    food_collected = True
                else:
                    print(f"Food found in cell {i}, move to cell")
                    self.move_to_cell(i)
                    time.sleep(0.7)
                    self.take_object('food')
                    food_collected = True
                break

        if food_collected:
            inventory_response = self.check_inventory()
            self.inventory = self.parse_inventory_response(inventory_response)

        print(f"Want to collect resource: {resource}")
        for i, cell in enumerate(vision):
            print(f"Checking cell {i}: {cell}")
            if resource in cell:
                if i == 0:
                    print(f"Resource {resource} found in cell {i}")
                    self.take_object(resource)
                    return
                else:
                    print(f"Resource {resource} found in cell {i}, move to cell")
                    self.move_to_cell(i)
                    #time.sleep(0.7)
                    self.take_object(resource)
                    return
    
        print(f"Resource {resource} not found in vision, moving forward")
        self.move_forward()


    def parse_inventory_response(self, response):
        print(f"Parsing inventory response: {response}")
        response = response.strip().lstrip('{').rstrip('}')
        inventory = {}
        for item in response.split(', '):
            try:
                item = item.strip('[] ')
                key, value = item.split()
                value = ''.join(filter(str.isdigit, value))
                inventory[key] = int(value)
            except ValueError as e:
                print(f"Error parsing item '{item}': {e}")
        return inventory

    def parse_look_response(self, response):
        print(f"Parsing look response: {response}")
        response = response.strip().lstrip('{').rstrip('}')
        return [cell.split() for cell in response.split(', ')]

    def decide_next_action(self, vision, inventory):
        required_resources = {
            1: {},
            2: {'linemate': 1},
            3: {'linemate': 1, 'deraumere': 1, 'sibur': 1},
            4: {'linemate': 2, 'sibur': 1, 'phiras': 2},
            5: {'linemate': 1, 'deraumere': 1, 'sibur': 2, 'phiras': 1},
            6: {'linemate': 1, 'deraumere': 2, 'sibur': 1, 'mendiane': 3},
            7: {'linemate': 1, 'deraumere': 2, 'sibur': 3, 'phiras': 1},
            8: {'linemate': 2, 'deraumere': 2, 'sibur': 2, 'mendiane': 2, 'phiras': 2, 'thystame': 1},
        }

        needed_resources = required_resources.get(self.current_level+1, {})
        for resource, amount in needed_resources.items():
            if inventory.get(resource, 0) < amount:
                print(f"Not enough {resource}")
                self.collect_resource(resource, vision)
                return

        if self.should_fork(vision):
            self.fork_player()

        print("All resources available for incantation")
        self.deposit_resources(needed_resources)
        self.check_incantation(vision)

    def should_fork(self, vision):
        required_players = self.required_players.get(self.current_level+1, 1)
        num_players = sum(1 for cell in vision for item in cell if item == 'player')
        return num_players < required_players and self.inventory.get('food', 0) > 5

    def deposit_resources(self, needed_resources):
        for resource, amount in needed_resources.items():
            for _ in range(amount):
                response = self.set_object_down(resource)
                print(f"Setting down {resource}: {response}")

    def check_incantation(self, vision):
        print("Check incantation")
        required_resources = {
            1: {},
            2: {'linemate': 1},
            3: {'linemate': 1, 'deraumere': 1, 'sibur': 1},
            4: {'linemate': 2, 'sibur': 1, 'phiras': 2},
            5: {'linemate': 1, 'deraumere': 1, 'sibur': 2, 'phiras': 1},
            6: {'linemate': 1, 'deraumere': 2, 'sibur': 1, 'mendiane': 3},
            7: {'linemate': 1, 'deraumere': 2, 'sibur': 3, 'phiras': 1},
            8: {'linemate': 2, 'deraumere': 2, 'sibur': 2, 'mendiane': 2, 'phiras': 2, 'thystame': 1},
        }

        needed_resources = required_resources.get(self.current_level+1, {})
        print(f"Needed resources for level {self.current_level+1}: {needed_resources}")
        print(f"Current inventory: {self.inventory}")
        if all(self.inventory.get(resource, 0) >= amount for resource, amount in needed_resources.items()):
            num_players = sum(1 for cell in vision for item in cell if item == 'player')
            required_players = self.required_players.get(self.current_level+1, 1)
            if num_players >= required_players:
                self.broadcast_message('Incantation')
                response = self.start_incantation()
                if "Elevation underway" in response:
                    self.handle_elevation()
            else:
                print("Not enough players for incantation")
        else:
            print("Not enough resources for incantation")

    def handle_elevation(self):
        while True:
            response = self.sock.recv(1024).decode().strip()
            print(f"Elevation response: {response}")
            if "Current level" in response:
                self.current_level += 1
                print(f"New level: {self.current_level}")
                break
            elif "dead" in response:
                print("Received 'dead' during elevation")
                self.close()
                break

    def move_to_cell(self, cell_index):
        print(f"Moving to cell: {cell_index}")
        if cell_index == 0:
            return
        moves = []
        if cell_index == 2:
            moves = ['Forward']
        elif cell_index == 6:
            moves = ['Forward'] * 2
        elif cell_index == 12:
            moves = ['Forward'] * 3
        elif cell_index in [1, 3]:
            moves = ['Forward']
            if cell_index == 1:
                moves.extend(['Left', 'Forward'])
            elif cell_index == 3:
                moves.extend(['Right', 'Forward'])
        elif cell_index in [4, 5, 7, 8]:
            moves = ['Forward'] * 2
            if cell_index == 4:
                moves.extend(['Left', 'Forward', 'Forward'])
            elif cell_index == 5:
                moves.extend(['Left', 'Forward'])
            elif cell_index == 7:
                moves.extend(['Right', 'Forward'])
            elif cell_index == 8:
                moves.extend(['Right', 'Forward', 'Forward'])
        elif cell_index in [9, 10, 11, 13, 14, 15]:
            moves = ['Forward'] * 3
            if cell_index == 9:
                moves.extend(['Left', 'Forward', 'Forward', 'Forward'])
            elif cell_index == 10:
                moves.extend(['Left', 'Forward', 'Forward'])
            elif cell_index == 11:
                moves.append(['Left', 'Forward'])
            elif cell_index == 13:
                moves.append(['Right', 'Forward'])
            elif cell_index == 14:
                moves.extend(['Right', 'Forward', 'Forward'])
            elif cell_index == 15:
                moves.extend(['Right', 'Forward', 'Forward', 'Forward'])

        for move in moves:
            self.send_command(move)
            time.sleep(0.5)

    def check_for_ejection(self, vision):
        for i, cell in enumerate(vision):
        if i == 0:
            players = [item for item in cell if item == 'player']
            if len(players) > 1:
                print("More than one player on the current cell")
                self.eject_players()
                
    def main_loop(self):
        while True:
            look_response = self.look_around()
            if "dead" in look_response:
                print("Received 'dead' message")
                self.close()
                break
            print(f"Look response: {look_response}")
            vision = self.parse_look_response(look_response)
            inventory_response = self.check_inventory()
            print(f"Inventory response: {inventory_response}")
            if "dead" in inventory_response:
                print("Received 'dead' message")
                self.close()
                break
            self.inventory = self.parse_inventory_response(inventory_response)
            self.check_for_ejection(vision)
            self.decide_next_action(vision, self.inventory)
            time.sleep(0.1)
    
    def close(self):
        try:
            self.sock.close()
        except Exception as e:
            print(f"An error occurred while closing the socket: {e}")