#!/usr/bin/env python3

import argparse
from IA.ai import ZappyAI

def main():
    parser = argparse.ArgumentParser(description="Zappy AI Client")
    parser.add_argument('--host', type=str, default='localhost', help='Server hostname')
    parser.add_argument('--port', type=int, required=True, help='Server port')
    parser.add_argument('--team_name', type=str, required=True, help='Team name')

    args = parser.parse_args()

    ai = ZappyAI(args.host, args.port, args.team_name)
    try:
        ai.connect()
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        ai.close()

if __name__ == "__main__":
    main()